/**
 * makurdi_export_v2.js  --  Google Earth Engine export for the EES resubmission.
 *
 * Re-creates the 500 m analysis grid of the original study EXACTLY (same ROI, same
 * coveringGrid, same SoilGrids/VIIRS/S2 definitions) so that the original table can be
 * re-joined row-by-row, and adds:
 *   - cell centroid coordinates (lon, lat) and a stable cell_id  -> 2-D spatial CV, AOA, spatial models
 *   - cloud-masked Sentinel-2 EVI from S2_SR_HARMONIZED (annual, dry-season, wet-season medians)
 *   - terrain/hydrology confounders: Copernicus GLO-30 elevation & slope, MERIT Hydro HAND and
 *     upstream area (-> TWI), JRC GSW water occurrence and distance to permanent water (Benue)
 *   - climate: CHIRPS 2024 rainfall, MODIS LST 2024 (day, dry season)
 *   - alternative urban axes: GHSL built-up surface fraction (2020), ESA WorldCover 2021 class
 *     fractions, VIIRS Black Marble VNP46A2 2024 mean (BRDF/moon-corrected)
 *   - a second, independent soil product: iSDAsoil (0-20 cm) means and SDs
 *   - SoilGrids 2.0 uncertainty layers (if available in the community catalog)
 *
 * Run in the Code Editor (Tasks tab -> RUN). Output: Drive/Makurdi_v2_cells.csv
 * Then place it at data/Makurdi_v2_cells.csv and run scripts/robustness_geo.py
 *
 * NOTE: verify asset IDs / scale factors against the GEE catalog before running; catalog
 * entries are versioned and occasionally renamed.
 */

// ---------------------------------------------------------------- 0. ROI and grid (unchanged)
var roi = ee.FeatureCollection('projects/disaster-management-474719/assets/MAKURDI');
var grid = roi.geometry().coveringGrid(ee.Projection('EPSG:4326'), 500).filterBounds(roi);
// keep original order + add id and centroid coordinates
var gridList = grid.toList(grid.size());
grid = ee.FeatureCollection(ee.List.sequence(0, grid.size().subtract(1)).map(function (i) {
  var f = ee.Feature(gridList.get(i));
  var c = f.geometry().centroid(1).coordinates();
  return f.set({cell_id: i, lon: c.get(0), lat: c.get(1)});
}));
var Y0 = '2024-01-01', Y1 = '2025-01-01';

// ---------------------------------------------------------------- 1. original variables (identical definitions)
function top30(asset, name, div) {
  return ee.Image(asset).select([0, 1, 2]).reduce(ee.Reducer.mean()).divide(div).rename(name);
}
var soil = top30('projects/soilgrids-isric/cec_mean', 'cec', 10)
  .addBands(top30('projects/soilgrids-isric/bdod_mean', 'bdod', 100))
  .addBands(top30('projects/soilgrids-isric/phh2o_mean', 'phh2o', 10))
  .addBands(top30('projects/soilgrids-isric/soc_mean', 'soc', 10))
  .addBands(top30('projects/soilgrids-isric/nitrogen_mean', 'nitrogen', 100))
  .addBands(top30('projects/soilgrids-isric/sand_mean', 'sand', 10))
  .addBands(top30('projects/soilgrids-isric/silt_mean', 'silt', 10))
  .addBands(top30('projects/soilgrids-isric/clay_mean', 'clay', 10));
var ntl = ee.ImageCollection('NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG').filterDate(Y0, Y1)
  .select('avg_rad').median().rename('NTL');
// original EVI (scene-level cloud filter only), kept for exact comparability
var s2old = ee.ImageCollection('COPERNICUS/S2_SR').filterBounds(roi).filterDate(Y0, Y1)
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 15)).select(['B2', 'B4', 'B8']).mean().divide(10000);
var eviOld = s2old.expression('2.5*((N-R)/(N+6*R-7.5*B+1))',
  {N: s2old.select('B8'), R: s2old.select('B4'), B: s2old.select('B2')}).rename('EVI');

// ---------------------------------------------------------------- 2. cloud-masked harmonized EVI
function prepS2(img) {
  var scl = img.select('SCL');
  var ok = scl.eq(4).or(scl.eq(5)).or(scl.eq(6)).or(scl.eq(7));       // veg, bare, water, unclassified
  var r = img.select(['B2', 'B4', 'B8']).divide(10000);
  var e = r.expression('2.5*((N-R)/(N+6*R-7.5*B+1))', {N: r.select('B8'), R: r.select('B4'), B: r.select('B2')});
  return e.rename('EVI').updateMask(ok).copyProperties(img, ['system:time_start']);
}
var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterBounds(roi).filterDate(Y0, Y1)
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 60)).map(prepS2);
var eviAnn = s2.median().rename('EVI_h_annual');
var eviDry = s2.filter(ee.Filter.or(ee.Filter.calendarRange(11, 12, 'month'), ee.Filter.calendarRange(1, 3, 'month')))
  .median().rename('EVI_h_dry');
var eviWet = s2.filter(ee.Filter.calendarRange(4, 10, 'month')).median().rename('EVI_h_wet');
var nObs = s2.count().rename('EVI_h_nobs');

// ---------------------------------------------------------------- 3. terrain and hydrology
var dem = ee.ImageCollection('COPERNICUS/DEM/GLO30').select('DEM').mosaic()
  .setDefaultProjection('EPSG:4326', null, 30);
var elev = dem.rename('elev');
var slope = ee.Terrain.slope(dem).rename('slope_deg');
var merit = ee.Image('MERIT/Hydro/v1_0_1');
var hand = merit.select('hnd').rename('hand');
var upaM2 = merit.select('upa').multiply(1e6);                         // km2 -> m2
var tanb = ee.Terrain.slope(merit.select('elv')).multiply(Math.PI / 180).tan().max(0.001);
var twi = upaM2.divide(90).divide(tanb).log().rename('twi');           // ln(a / tan b), a per 90 m width
var gsw = ee.Image('JRC/GSW1_4/GlobalSurfaceWater').select('occurrence').unmask(0);
var water = gsw.gt(50);
var distWater = water.selfMask().fastDistanceTransform(256).sqrt()
  .multiply(ee.Image.pixelArea().sqrt()).rename('dist_water_m');
var waterFrac = gsw.divide(100).rename('water_occ');

// ---------------------------------------------------------------- 4. climate
var rain = ee.ImageCollection('UCSB-CHG/CHIRPS/DAILY').filterDate(Y0, Y1).select('precipitation').sum().rename('rain_mm');
var lst = ee.ImageCollection('MODIS/061/MOD11A2').filterDate(Y0, Y1).select('LST_Day_1km')
  .mean().multiply(0.02).subtract(273.15).rename('lst_day_c');

// ---------------------------------------------------------------- 5. alternative urban axes
var built = ee.Image('JRC/GHSL/P2023A/GHS_BUILT_S/2020').select('built_surface')
  .divide(10000).rename('built_frac');                                  // m2 per 100 m cell -> fraction
var wc = ee.ImageCollection('ESA/WorldCover/v200').first().select('Map');
var wcFr = ee.Image.cat([
  wc.eq(10).rename('wc_tree'), wc.eq(20).rename('wc_shrub'), wc.eq(30).rename('wc_grass'),
  wc.eq(40).rename('wc_crop'), wc.eq(50).rename('wc_built'), wc.eq(60).rename('wc_bare'),
  wc.eq(80).rename('wc_water'), wc.eq(90).rename('wc_wetland')]);
var bm = ee.ImageCollection('NASA/VIIRS/002/VNP46A2').filterDate(Y0, Y1)
  .select('Gap_Filled_DNB_BRDF_Corrected_NTL').mean().multiply(0.1).rename('ntl_bm'); // verify scale in catalog

// ---------------------------------------------------------------- 6. iSDAsoil (independent soil product, 0-20 cm)
function isda(name, band, fn) {
  var im = ee.Image('ISDASOIL/Africa/v1/' + name);
  return [fn(im.select('mean_0_20')).rename('isda_' + band), im.select('stdev_0_20').rename('isda_' + band + '_sdraw')];
}
var expm1 = function (k) { return function (x) { return x.divide(k).exp().subtract(1); }; };
var lin = function (k) { return function (x) { return x.divide(k); }; };
var isdaL = [].concat(
  isda('ph', 'ph', lin(10)), isda('carbon_organic', 'soc', expm1(10)), isda('nitrogen_total', 'n', expm1(100)),
  isda('bulk_density', 'bd', lin(100)), isda('clay_content', 'clay', lin(1)), isda('sand_content', 'sand', lin(1)),
  isda('silt_content', 'silt', lin(1)), isda('cation_exchange_capacity', 'cec', expm1(10)));
var isdaImg = ee.Image.cat(isdaL);

// ---------------------------------------------------------------- 7. SoilGrids uncertainty (optional)
// ISRIC publishes Q0.05/Q0.95 and an 'uncertainty' layer; if your catalog exposes them, set true.
var USE_SG_UNC = false;
var sgUnc = ee.Image([]);
if (USE_SG_UNC) {
  ['phh2o', 'soc', 'bdod', 'clay'].forEach(function (p) {
    sgUnc = sgUnc.addBands(ee.Image('projects/soilgrids-isric/' + p + '_uncertainty')
      .select([0, 1, 2]).reduce(ee.Reducer.mean()).rename('sgunc_' + p));
  });
}

// ---------------------------------------------------------------- 8. export
// (a) original block at the ORIGINAL scale (250 m) so values match the archived table exactly
var orig = ntl.addBands(eviOld).addBands(soil);
Export.table.toDrive({
  collection: orig.reduceRegions({collection: grid, reducer: ee.Reducer.mean(), scale: 250})
    .map(function (f) { return f.setGeometry(null); }),
  description: 'Makurdi_v2_original', fileFormat: 'CSV'
});
// (b) new covariates at 100 m (finer than every input except DEM/S2), joined on cell_id in Python
var stack = eviAnn.addBands(eviDry).addBands(eviWet).addBands(nObs)
  .addBands(elev).addBands(slope).addBands(hand).addBands(twi).addBands(distWater).addBands(waterFrac)
  .addBands(rain).addBands(lst).addBands(built).addBands(wcFr).addBands(bm).addBands(isdaImg).addBands(sgUnc);

var out = stack.reduceRegions({collection: grid, reducer: ee.Reducer.mean(), scale: 100, tileScale: 4});
Export.table.toDrive({
  collection: out.map(function (f) { return f.setGeometry(null); }),
  description: 'Makurdi_v2_cells', fileFormat: 'CSV'
});
// Also export the grid polygons for mapping (GeoJSON)
Export.table.toDrive({collection: grid, description: 'Makurdi_v2_grid', fileFormat: 'GeoJSON'});
