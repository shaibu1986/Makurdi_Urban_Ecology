"""
robustness_geo.py  --  tests that need the v2 Earth Engine export (coordinates + confounders).

Inputs : data/Makurdi_v2_original.csv  and  data/Makurdi_v2_cells.csv   (from scripts/gee/makurdi_export_v2.js)
Outputs: results/R_geo.json, results/macros_geo.tex, figs/fig13_*.png, figs/fig14_*.png

Tests
  0. Integrity: re-exported original block matches the archived table row-for-row (confirms scan order)
  1. 2-D spatial block CV (block size >= residual autocorrelation range) and area of applicability (AOA)
  2. H1 vs H2 with geomorphic confounders: 3-way variance partitioning (urban / soil / terrain-climate),
     SOC-EVI partial correlation given terrain, mediation with terrain covariates
  3. Circularity negative control: EVI from SoilGrids vs iSDAsoil vs terrain-only (EVI-free) predictors
     + SoilGrids-iSDAsoil agreement along the urban gradient
  4. H3 under a spatial-error model (and with terrain covariates)
  5. Alternative urban axes (GHSL built-up fraction, Black Marble) and season (dry vs wet EVI)
Requires: pandas numpy scikit-learn statsmodels scipy matplotlib libpysal spreg
"""
import json, os, sys, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_predict
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
warnings.filterwarnings('ignore')
os.makedirs('results', exist_ok=True); os.makedirs('figs', exist_ok=True)
SEED = 42; NTREE = int(os.environ.get('NTREE', 500)); NBOOT = int(os.environ.get('NBOOT', 1000))
SOIL = ['cec', 'bdod', 'phh2o', 'soc', 'nitrogen', 'sand', 'silt', 'clay']
ISDA = ['isda_cec', 'isda_bd', 'isda_ph', 'isda_soc', 'isda_n', 'isda_sand', 'isda_silt', 'isda_clay']
TERR = ['elev', 'slope_deg', 'hand', 'twi', 'dist_water_m', 'water_occ', 'rain_mm', 'lst_day_c']
R = {}

o = pd.read_csv('data/Makurdi_v2_original.csv'); c = pd.read_csv('data/Makurdi_v2_cells.csv')
D = o.merge(c.drop(columns=[k for k in c.columns if k in o.columns and k != 'cell_id']), on='cell_id').sort_values('cell_id')
# ---------------------------------------------------------------- 0. integrity vs archived table
arch = pd.read_csv('data/Makurdi_Full_Suite_EVI_Data.csv')
if len(arch) == len(D):
    R['integrity'] = {v: round(float(np.corrcoef(arch[v].fillna(-9), D[v].fillna(-9))[0, 1]), 4) for v in ['NTL', 'EVI', 'soc', 'phh2o']}
else:
    R['integrity'] = dict(n_archived=len(arch), n_v2=len(D))
print('integrity', R['integrity'])

need = ['NTL', 'EVI', 'lon', 'lat'] + SOIL + TERR
df = D.dropna(subset=need).reset_index(drop=True); y = df.EVI.values; n = len(df)
km_x = (df.lon - df.lon.mean()) * 111.32 * np.cos(np.radians(df.lat.mean())); km_y = (df.lat - df.lat.mean()) * 110.57
XY = np.column_stack([km_x, km_y])
R['n'] = n

# ---------------------------------------------------------------- 1. residual variogram -> block size; 2-D block CV; AOA
ols = sm.OLS(y, sm.add_constant(df[['NTL'] + SOIL])).fit(); e = ols.resid.values
rs = np.random.default_rng(SEED); ii = rs.choice(n, min(n, 2500), replace=False)
dd = np.sqrt(((XY[ii, None, :] - XY[None, ii, :]) ** 2).sum(-1)); ee = (e[ii, None] - e[None, ii]) ** 2 / 2
edges = np.arange(0, 15.5, 0.5); gam = [ee[(dd > a) & (dd <= b)].mean() for a, b in zip(edges[:-1], edges[1:])]
sill = np.var(e); rng_km = float(edges[1:][np.argmax(np.array(gam) >= 0.95 * sill)]) if (np.array(gam) >= .95 * sill).any() else 15.0
R['variogram_range_km'] = rng_km
bs = max(2.0, rng_km)
bid = (np.floor(km_x / bs).astype(int).astype(str) + '_' + np.floor(km_y / bs).astype(int).astype(str)).values
ub = np.unique(bid); fold_of_block = dict(zip(ub, np.random.default_rng(SEED).permutation(len(ub)) % 10))
fold = np.array([fold_of_block[b] for b in bid])
def rf(leaf=1): return RandomForestRegressor(n_estimators=NTREE, min_samples_leaf=leaf, random_state=SEED, n_jobs=-1)
def spcv(cols, leaf=20, data=None, yy=None):
    data = df if data is None else data; yy = y if yy is None else yy
    return cross_val_predict(rf(leaf), data[cols], yy, cv=GroupKFold(10), groups=fold)
def rdcv(cols, leaf=20): return cross_val_predict(rf(leaf), df[cols], y, cv=KFold(10, shuffle=True, random_state=SEED))
R['block_km'] = bs; R['cv2d'] = {'random': round(r2_score(y, rdcv(['NTL'] + SOIL, 1)), 3),
                                 'block2d': round(r2_score(y, spcv(['NTL'] + SOIL, 1)), 3),
                                 'block2d_reg': round(r2_score(y, spcv(['NTL'] + SOIL, 20)), 3)}
# AOA (Meyer & Pebesma 2021): dissimilarity index with importance weights; threshold from CV DI
Xs = StandardScaler().fit_transform(df[['NTL'] + SOIL]); w = rf(5).fit(df[['NTL'] + SOIL], y).feature_importances_; Xw = Xs * w
from sklearn.neighbors import NearestNeighbors
sub = Xw[rs.choice(n, min(n, 1000), replace=False)]
dbar = np.mean(np.sqrt(((sub[:, None] - sub[None]) ** 2).sum(-1)))   # mean pairwise distance in weighted space
di_cv = np.zeros(n)
for k in range(10):
    tr, te = fold != k, fold == k
    di_cv[te] = NearestNeighbors(n_neighbors=1).fit(Xw[tr]).kneighbors(Xw[te])[0][:, 0] / dbar
q75, q25 = np.percentile(di_cv, [75, 25]); thr = di_cv[di_cv <= q75 + 1.5 * (q75 - q25)].max()
# DI of the EXCLUDED (masked) cells cannot be computed (no soil values) -> report AOA among retained + by NTL class
inaoa = di_cv <= thr; R['aoa'] = dict(threshold=round(float(thr), 3), share_in=round(float(inaoa.mean()), 3),
    share_in_by_ntl={k: round(float(inaoa[m].mean()), 3) for k, m in
                     [('le1', df.NTL <= 1), ('1to2', (df.NTL > 1) & (df.NTL <= 2)), ('gt2', df.NTL > 2)] if m.sum() > 0})
print('cv2d', R['cv2d'], 'aoa', R['aoa'])

# ---------------------------------------------------------------- 2. H1 vs H2 with confounders
URB = ['NTL'] + (['built_frac'] if 'built_frac' in df else [])
sets = {'U': URB, 'S': SOIL, 'T': TERR}
from itertools import combinations
r2 = {}
for k in range(1, 4):
    for comb in combinations('UST', k):
        cols = sum([sets[s] for s in comb], []); r2[''.join(comb)] = r2_score(y, spcv(cols))
# 3-way commonality (Legendre-style fractions) from spatial-CV R2
U, S, T = r2['U'], r2['S'], r2['T']; US, UT, ST, UST = r2['US'], r2['UT'], r2['ST'], r2['UST']
frac = dict(u=UST - ST, s=UST - UT, t=UST - US, all=UST)
R['vp3'] = {k: round(v, 3) for k, v in {**{f'R2_{k}': v for k, v in r2.items()}, **frac}.items()}
# OLS adjusted R2 analogue
def adj(cols): return sm.OLS(y, sm.add_constant(df[cols])).fit().rsquared_adj
R['vp3_ols'] = {k: round(adj(sum([sets[s] for s in k], [])), 3) for k in ['U', 'S', 'T', 'US', 'ST', 'UT', 'UST']}
# SOC-EVI association: raw vs partial on terrain (does the negative sign survive hydromorphy controls?)
Zt = sm.add_constant(StandardScaler().fit_transform(df[TERR]))
res_soc = sm.OLS(df.soc, Zt).fit().resid; res_evi = sm.OLS(y, Zt).fit().resid
R['soc_evi'] = dict(raw=round(float(np.corrcoef(df.soc, y)[0, 1]), 3), partial_terrain=round(float(np.corrcoef(res_soc, res_evi)[0, 1]), 3))
for t in ['hand', 'twi', 'dist_water_m']: R['soc_evi'][f'r_soc_{t}'] = round(float(np.corrcoef(df.soc, df[t])[0, 1]), 3)
# mediation with terrain covariates
Zs = StandardScaler().fit_transform(df[SOIL]); pcs = PCA(3).fit(Zs).transform(Zs)
d = pd.DataFrame({'EVI': y, 'lNTL': np.log(df.NTL.clip(lower=0.01)), 'PC1': pcs[:, 0], 'PC2': pcs[:, 1], 'PC3': pcs[:, 2], 'ph': df.phh2o})
if np.corrcoef(d.PC1, df.sand)[0, 1] < 0: d['PC1'] *= -1
for t in TERR: d[t] = df[t].values
d = (d - d.mean()) / d.std(); d['fold'] = fold; d['blk'] = bid
tf = '+'.join(TERR)
def med(s, cov=''):
    m = smf.ols('EVI~lNTL+PC1+PC2+PC3' + cov, s).fit()
    ind = [smf.ols(f'PC{i}~lNTL' + cov, s).fit().params['lNTL'] * m.params[f'PC{i}'] for i in (1, 2, 3)]
    return [sum(ind), m.params['lNTL']]
def cluster_boot(fun, s, B):
    r = np.random.default_rng(1); blocks = s.blk.unique(); g = {b: s.index[s.blk == b].values for b in blocks}; out = []
    for _ in range(B):
        ii = np.concatenate([g[b] for b in r.choice(blocks, len(blocks))]); out.append(fun(s.loc[ii].reset_index(drop=True)))
    return np.array(out)
for nm, cov in [('no_terrain', ''), ('terrain', '+' + tf)]:
    est = med(d, cov); B = cluster_boot(lambda s: med(s, cov), d, NBOOT)
    R[f'med_{nm}'] = dict(ind=round(est[0], 4), ind_ci=np.percentile(B[:, 0], [2.5, 97.5]).round(4).tolist(),
                          dir=round(est[1], 4), dir_ci=np.percentile(B[:, 1], [2.5, 97.5]).round(4).tolist())
print('vp3', R['vp3'], R['soc_evi'], R['med_terrain'])

# ---------------------------------------------------------------- 3. circularity negative control
circ = {}
have_isda = all(k in df for k in ISDA) and df[ISDA].notna().all(axis=1).mean() > .9
for nm, cols in [('soilgrids', SOIL), ('terrain_only', TERR), ('terrain_soilgrids', TERR + SOIL)] + \
        ([('isda', ISDA), ('terrain_isda', TERR + ISDA)] if have_isda else []):
    m = df[cols].notna().all(axis=1).values
    circ[nm] = round(r2_score(y[m], cross_val_predict(rf(20), df.loc[m, cols], y[m], cv=GroupKFold(10), groups=fold[m])), 3)
circ['soilgrids_gain_over_terrain'] = round(circ['terrain_soilgrids'] - circ['terrain_only'], 3)
if have_isda:
    circ['isda_gain_over_terrain'] = round(circ['terrain_isda'] - circ['terrain_only'], 3)
    pairs = [('phh2o', 'isda_ph'), ('soc', 'isda_soc'), ('bdod', 'isda_bd'), ('clay', 'isda_clay'), ('sand', 'isda_sand')]
    def ccc(a, b): return 2 * np.cov(a, b)[0, 1] / (a.var() + b.var() + (a.mean() - b.mean()) ** 2)
    agree = {}
    for sg, isd in pairs:
        m = df[[sg, isd]].notna().all(axis=1)
        agree[sg] = dict(r=round(float(np.corrcoef(df.loc[m, sg], df.loc[m, isd])[0, 1]), 3), ccc=round(float(ccc(df.loc[m, sg], df.loc[m, isd])), 3),
                         r_evi_sg=round(float(np.corrcoef(df.loc[m, sg], y[m])[0, 1]), 3), r_evi_isda=round(float(np.corrcoef(df.loc[m, isd], y[m])[0, 1]), 3))
    circ['agreement'] = agree
    # coverage of each product along the urban gradient (on the FULL grid)
    cov = {}
    for nm, col in [('soilgrids', 'soc'), ('isda', 'isda_soc')]:
        cov[nm] = {k: round(float(D.loc[m_, col].isna().mean()), 3) for k, m_ in
                   [('le0.5', D.NTL <= .5), ('0.5-2', (D.NTL > .5) & (D.NTL <= 2)), ('2-4', (D.NTL > 2) & (D.NTL <= 4)), ('gt4', D.NTL > 4)]}
    circ['missing_share'] = cov
R['circularity'] = circ; print('circ', circ)

# ---------------------------------------------------------------- 4. H3 under spatial error model
f = 'EVI~ph*lNTL'
h3 = {'ols_cluster': smf.ols(f, d).fit(cov_type='cluster', cov_kwds={'groups': d.blk}),
      'ols_cluster_terrain': smf.ols(f + '+' + tf, d).fit(cov_type='cluster', cov_kwds={'groups': d.blk})}
R['h3'] = {k: dict(b=round(m.params['ph:lNTL'], 4), p=float(m.pvalues['ph:lNTL'])) for k, m in h3.items()}
try:
    from libpysal.weights import KNN; from spreg import ML_Error
    W = KNN.from_array(XY, k=8); W.transform = 'r'
    X = np.column_stack([d.ph, d.lNTL, d.ph * d.lNTL]); me = ML_Error(d.EVI.values[:, None], X, w=W, name_x=['ph', 'lNTL', 'ph_x_lNTL'])
    R['h3']['sem'] = dict(b=round(float(me.betas[3][0]), 4), p=float(me.z_stat[3][1]), lam=round(float(me.lam), 3))
    Xt = np.column_stack([X, d[TERR].values]); me2 = ML_Error(d.EVI.values[:, None], Xt, w=W)
    R['h3']['sem_terrain'] = dict(b=round(float(me2.betas[3][0]), 4), p=float(me2.z_stat[3][1]), lam=round(float(me2.lam), 3))
    from esda.moran import Moran
    R['moran_ols_resid'] = round(float(Moran(sm.OLS(d.EVI, sm.add_constant(X)).fit().resid, W).I), 3)
except Exception as ex:
    R['h3']['sem_error'] = str(ex)
print('h3', R['h3'])

# ---------------------------------------------------------------- 5. alternative urban axes + season
alt = {}
for ax_ in ['built_frac', 'ntl_bm']:
    if ax_ in df and df[ax_].notna().mean() > .9:
        dz = d.copy(); dz['lNTL'] = StandardScaler().fit_transform(np.log1p(df[[ax_]].clip(lower=0)))[:, 0]
        est = med(dz.dropna(), '+' + tf); alt[ax_] = dict(ind=round(est[0], 4), dir=round(est[1], 4),
            h3_b=round(smf.ols(f + '+' + tf, dz).fit().params['ph:lNTL'], 4), h3_p=float(smf.ols(f + '+' + tf, dz).fit(cov_type='cluster', cov_kwds={'groups': dz.blk}).pvalues['ph:lNTL']))
R['alt_axes'] = alt
sea = {}
for s_ in ['EVI_h_annual', 'EVI_h_dry', 'EVI_h_wet']:
    if s_ in df and df[s_].notna().mean() > .9:
        m = df[s_].notna().values; yy = df.loc[m, s_].values
        sea[s_] = dict(r_old=round(float(np.corrcoef(yy, y[m])[0, 1]), 3), r_soc=round(float(np.corrcoef(df.soc[m], yy)[0, 1]), 3),
                       r_ph=round(float(np.corrcoef(df.phh2o[m], yy)[0, 1]), 3), r_ntl=round(float(np.corrcoef(np.log(df.NTL[m]), yy)[0, 1]), 3),
                       cv_soil=round(r2_score(yy, cross_val_predict(rf(20), df.loc[m, SOIL], yy, cv=GroupKFold(10), groups=fold[m])), 3))
R['season'] = sea; print('alt', alt, 'season', sea)
json.dump(R, open('results/R_geo.json', 'w'), indent=1, default=float)

# ---------------------------------------------------------------- figures
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
B_, O_, A_, INK, MUTE, GRID = '#2a78d6', '#eb6834', '#1baf7a', '#0b0b0b', '#52514e', '#dddcd6'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'savefig.dpi': 300})
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
keys = [k for k in ['terrain_only', 'soilgrids', 'isda', 'terrain_soilgrids', 'terrain_isda'] if k in circ]
lbl = {'terrain_only': 'Terrain +\nclimate', 'soilgrids': 'SoilGrids', 'isda': 'iSDAsoil', 'terrain_soilgrids': 'Terrain +\nSoilGrids', 'terrain_isda': 'Terrain +\niSDAsoil'}
ax[0].bar(range(len(keys)), [circ[k] for k in keys], color=[A_ if 'terrain' == k.split('_')[0] and k == 'terrain_only' else B_ for k in keys])
ax[0].set_xticks(range(len(keys)), [lbl[k] for k in keys], fontsize=7.5); ax[0].set_ylabel('Spatial-block CV R$^2$ (EVI)'); ax[0].text(-.15, 1.03, 'a', transform=ax[0].transAxes, fontweight='bold', fontsize=11)
vk = ['u', 's', 't']; ax[1].bar(['Unique urban', 'Unique soil', 'Unique terrain'], [frac[k] for k in vk], color=[O_, B_, A_])
ax[1].set_ylabel('Unique spatial-CV R$^2$'); ax[1].text(-.15, 1.03, 'b', transform=ax[1].transAxes, fontweight='bold', fontsize=11)
plt.tight_layout(); plt.savefig('figs/fig13_circularity_partition.png'); plt.close()

# ---------------------------------------------------------------- macros
def f3(x): return f'{x:.3f}'.replace('-', '\\ensuremath{-}')
def ci(c): return f'{c[0]:.3f} to {c[1]:.3f}'.replace('-', '\\ensuremath{-}')
def pf(p): return '< 0.001' if p < 0.001 else f'= {p:.3f}'
M = dict(geoN=f'{n:,}', geoBlockKm=f'{bs:.1f}', geoRangeKm=f'{rng_km:.1f}', geoCvRandom=f3(R['cv2d']['random']),
         geoCvBlock=f3(R['cv2d']['block2d']), geoCvBlockReg=f3(R['cv2d']['block2d_reg']), geoAoaIn=f"{100 * R['aoa']['share_in']:.0f}",
         geoUniqueU=f3(frac['u']), geoUniqueS=f3(frac['s']), geoUniqueT=f3(frac['t']), geoAll=f3(frac['all']),
         geoSocRaw=f3(R['soc_evi']['raw']), geoSocPartial=f3(R['soc_evi']['partial_terrain']), geoSocHand=f3(R['soc_evi']['r_soc_hand']),
         geoMedInd=f3(R['med_terrain']['ind']), geoMedIndCI=ci(R['med_terrain']['ind_ci']), geoMedDir=f3(R['med_terrain']['dir']), geoMedDirCI=ci(R['med_terrain']['dir_ci']),
         geoCircTerr=f3(circ['terrain_only']), geoCircSG=f3(circ['soilgrids']), geoCircGainSG=f3(circ['soilgrids_gain_over_terrain']),
         geoHThreeB=f3(R['h3']['ols_cluster_terrain']['b']), geoHThreeP=pf(R['h3']['ols_cluster_terrain']['p']))
if have_isda: M.update(geoCircISDA=f3(circ['isda']), geoCircGainISDA=f3(circ['isda_gain_over_terrain']),
                       geoAgreePhR=f3(circ['agreement']['phh2o']['r']), geoAgreeSocR=f3(circ['agreement']['soc']['r']))
if 'sem_terrain' in R['h3']: M.update(geoSemB=f3(R['h3']['sem_terrain']['b']), geoSemP=pf(R['h3']['sem_terrain']['p']), geoSemLam=f3(R['h3']['sem_terrain']['lam']))
with open('results/macros_geo.tex', 'w') as fh:
    fh.write('% auto-generated by scripts/robustness_geo.py\n\\geoavailabletrue\n')
    for k_, v_ in M.items(): fh.write(f'\\renewcommand{{\\{k_}}}{{{v_}}}\n')
print('done')
