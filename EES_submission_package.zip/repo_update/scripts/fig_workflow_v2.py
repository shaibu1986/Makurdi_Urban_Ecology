"""Regenerates Fig. 3 (workflow, six stages) for the EES manuscript."""
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
B, O, A, MUTE, INK = '#2a78d6', '#eb6834', '#1baf7a', '#52514e', '#0b0b0b'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'savefig.dpi': 300})
st = [('1. Data fusion', 'Google Earth Engine: VIIRS nighttime lights (2024 median), Sentinel-2 EVI (2024 mean),\nSoilGrids 2.0 (CEC, BD, pH, SOC, N, sand, silt, clay; 0-30 cm mean)', B),
      ('2. Grid &\ncoverage audit', '500 m grid (3,773 cells); cells lacking soil values compared with retained cells\nalong the NTL gradient; 3,507 analysable cells', O),
      ('3. Model &\nvalidation', 'Random Forest; apparent, random, feature-space and geographic (buffered band) CV;\nout-of-fold permutation importance; accumulated local effects', B),
      ('4. Hypothesis\ntests', 'H1-H3: variance partitioning (urban vs soil); multiple-mediator model via three soil\nprincipal components; NTL x soil coupling (terciles, continuous interaction)', A),
      ('5. Breakpoints', 'Segmented regression with F-test and dAIC; bootstrap confidence intervals', A),
      ('6. Spatial\nrobustness', 'Scan-order correlogram, Moran\'s I, effective n; moving-block bootstrap; scan-line\ncluster-robust SEs; latitude-band fixed effects; leave-one-band-out; screening protocol', O)]
fig, ax = plt.subplots(figsize=(7.4, 5.6)); ax.set_xlim(0, 13); ax.set_ylim(-0.6, 12.4); ax.axis('off')
h, gap = 1.5, 0.45
for i, (t, d, c) in enumerate(st):
    y = 12 - (i + 1) * h - i * gap
    ax.add_patch(FancyBboxPatch((0.05, y), 2.5, h, boxstyle='round,pad=0.02,rounding_size=0.12', ec=c, fc=c, lw=1.4))
    ax.text(1.3, y + h / 2, t, ha='center', va='center', color='white', fontweight='bold', fontsize=8)
    ax.add_patch(FancyBboxPatch((2.75, y), 10.2, h, boxstyle='round,pad=0.02,rounding_size=0.12', ec=c, fc='white', lw=1.4))
    ax.text(2.95, y + h / 2, d, ha='left', va='center', fontsize=7.1, color=INK, linespacing=1.45)
    if i < len(st) - 1:
        ax.add_patch(FancyArrowPatch((1.3, y - 0.02), (1.3, y - gap + 0.02), arrowstyle='-|>', mutation_scale=12, color=MUTE, lw=1.4))
plt.savefig('figs/fig3_workflow_v2.png', bbox_inches='tight'); plt.close()
