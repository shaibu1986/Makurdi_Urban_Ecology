"""
robustness_scan.py  --  spatial-structure robustness tests that run on the ARCHIVED table.

The archived table (data/Makurdi_Full_Suite_EVI_Data.csv) carries no coordinates, but its
rows are in Earth Engine coveringGrid order, i.e. a raster scan of 500 m cells: consecutive
rows are east-west neighbours and the series repeats every ~70 rows (one scan line).
This script (1) documents that structure, (2) uses contiguous runs of rows as LATITUDE BANDS
for geographic block cross-validation with optional buffers, (3) re-estimates the
hypothesis tests with spatially robust uncertainty (moving-block bootstrap; cluster-robust
SEs with scan-line clusters), and (4) replaces partial dependence with accumulated local
effects (ALE), which are valid for correlated predictors.

Usage:  python scripts/robustness_scan.py         (writes results/R_scan.json, results/macros_scan.tex, figs/*)
Requires: pandas numpy scikit-learn statsmodels scipy matplotlib
"""
import json, os, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
warnings.filterwarnings('ignore')
os.makedirs('results', exist_ok=True); os.makedirs('figs', exist_ok=True)
SEED = 42; NTREE = int(os.environ.get('NTREE', 500)); NBOOT = int(os.environ.get('NBOOT', 1000))
SOIL = ['cec', 'bdod', 'phh2o', 'soc', 'nitrogen', 'sand', 'silt', 'clay']
R = {}

raw = pd.read_csv('data/Makurdi_Full_Suite_EVI_Data.csv')
raw['scan_idx'] = np.arange(len(raw))                      # position in coveringGrid order
df = raw.dropna().reset_index(drop=True)
y = df.EVI.values; n = len(df)

# ---------------------------------------------------------------- 1. scan structure
def acf(x, lags):
    x = (x - np.nanmean(x)) / np.nanstd(x)
    return np.array([np.nanmean(x[:-k] * x[k:]) for k in lags])
lags = np.arange(1, 141)
xr = raw[['NTL', 'EVI', 'phh2o', 'sand']].interpolate(limit_direction='both')
ac = {c: acf(xr[c].values, lags) for c in xr}
period = int(lags[20:][np.argmax(ac['NTL'][20:])])
R['scan'] = dict(period=period, n_lines=round(len(raw) / period, 1),
                 lag1={c: round(float(ac[c][0]), 3) for c in ac},
                 lag_period={c: round(float(ac[c][period - 1]), 3) for c in ac})
print('scan', R['scan'])

# residual correlogram along the scan (OLS on soil + NTL) -> autocorrelation range
ols_full = sm.OLS(y, sm.add_constant(df[['NTL'] + SOIL])).fit()
res = pd.Series(np.nan, index=raw.index); res[raw.dropna().index] = ols_full.resid.values
rac = acf(res.interpolate(limit_direction='both').values, lags)
rng_cells = int(np.argmax(rac[:period // 2] < 0.1) + 1) if (rac[:period // 2] < 0.1).any() else period // 2
R['resid_acf'] = dict(lag1=round(float(rac[0]), 3), lag_line=round(float(rac[period - 1]), 3),
                      range_cells=rng_cells, range_km=round(rng_cells * 0.5, 1))
# effective sample size under AR(1) along the scan
rho = float(rac[0]); R['n_eff_ar1'] = int(round(n * (1 - rho) / (1 + rho)))
print('resid', R['resid_acf'], 'n_eff', R['n_eff_ar1'])

# along-row Moran's I of OLS residuals (neighbours = i +/- 1 in scan order)
e = ols_full.resid.values - ols_full.resid.values.mean(); si = df.scan_idx.values
adj = np.where(np.diff(si) == 1)[0]
I = (len(e) / (2 * len(adj))) * (2 * np.sum(e[adj] * e[adj + 1])) / np.sum(e ** 2)
R['moran_row'] = round(float(I), 3)

# ---------------------------------------------------------------- 2. geographic (band) CV
K = 10
band = pd.qcut(df.scan_idx, K, labels=False).values                 # ~5.4 scan lines (~2.7 km) each
df['band'] = band
def rf(leaf=1): return RandomForestRegressor(n_estimators=NTREE, min_samples_leaf=leaf, random_state=SEED, n_jobs=-1)

def band_cv(cols, leaf=1, buffer_lines=0):
    pred = np.full(n, np.nan); X = df[cols].values
    for b in range(K):
        te = band == b
        lo, hi = df.scan_idx[te].min(), df.scan_idx[te].max()
        buf = buffer_lines * period
        tr = (~te) & ((df.scan_idx < lo - buf) | (df.scan_idx > hi + buf))
        pred[te] = rf(leaf).fit(X[tr], y[tr]).predict(X[te])
    return pred

def metr(p): return dict(R2=round(r2_score(y, p), 3), RMSE=round(mean_squared_error(y, p) ** .5, 4))
Xf = df[['NTL'] + SOIL]
gfeat = KMeans(10, random_state=SEED, n_init=10).fit_predict(StandardScaler().fit_transform(df[SOIL]))
cv = {}
for leaf, tag in [(1, 'full'), (20, 'reg')]:
    cv[f'random_{tag}'] = metr(cross_val_predict(rf(leaf), Xf, y, cv=KFold(10, shuffle=True, random_state=SEED)))
    cv[f'feature_{tag}'] = metr(cross_val_predict(rf(leaf), Xf, y, cv=GroupKFold(10), groups=gfeat))
    for bl in (0, 1, 2):
        cv[f'band{bl}_{tag}'] = metr(band_cv(['NTL'] + SOIL, leaf, bl))
    print(tag, {k: v for k, v in cv.items() if k.endswith(tag)})
R['cv'] = cv

# variance partitioning under band CV (regularised RF, 1-line buffer)
vp = {}
for nm, cols in [('full', ['NTL'] + SOIL), ('soil', SOIL), ('ntl', ['NTL'])]:
    vp[nm] = r2_score(y, band_cv(cols, 20, 1))
vp['unique_ntl'] = vp['full'] - vp['soil']; R['vp_band'] = {k: round(v, 3) for k, v in vp.items()}
print('vp_band', R['vp_band'])

# ---------------------------------------------------------------- 3. spatially robust inference
Z = StandardScaler().fit_transform(df[SOIL]); pcs = PCA(3).fit(Z).transform(Z)
d = pd.DataFrame({'EVI': y, 'lNTL': np.log(df.NTL), 'PC1': pcs[:, 0], 'PC2': pcs[:, 1], 'PC3': pcs[:, 2],
                  'ph': df.phh2o, 'scan': df.scan_idx, 'band': band})
# PCA sign convention: make PC1 load positively on sand (as in the manuscript)
if np.corrcoef(d.PC1, df.sand)[0, 1] < 0: d['PC1'] *= -1
for c in ['EVI', 'lNTL', 'PC1', 'PC2', 'PC3', 'ph']: d[c + '_z'] = (d[c] - d[c].mean()) / d[c].std()
line = (d.scan // period).astype(int); d['cl2'] = line // 2                    # 2-line clusters (~1 km)

def med(s):
    m = smf.ols('EVI_z~lNTL_z+PC1_z+PC2_z+PC3_z', s).fit()
    ind = [smf.ols(f'PC{i}_z~lNTL_z', s).fit().params['lNTL_z'] * m.params[f'PC{i}_z'] for i in (1, 2, 3)]
    return ind + [sum(ind), m.params['lNTL_z']]
est = med(d)

def block_boot(fun, data, L, B, seed=1):
    """moving-block bootstrap along scan order, block length L rows"""
    r = np.random.default_rng(seed); idx = np.arange(len(data)); nb = int(np.ceil(len(data) / L)); out = []
    for _ in range(B):
        st = r.integers(0, len(data) - L, nb); ii = np.concatenate([idx[s:s + L] for s in st])[:len(data)]
        out.append(fun(data.iloc[ii].reset_index(drop=True)))
    return np.array(out)
def iid_boot(fun, data, B, seed=1):
    r = np.random.default_rng(seed)
    return np.array([fun(data.iloc[r.integers(0, len(data), len(data))].reset_index(drop=True)) for _ in range(B)])

Bi = iid_boot(med, d, NBOOT); Bb = block_boot(med, d, 2 * period, NBOOT)
lab = ['ind_PC1', 'ind_PC2', 'ind_PC3', 'ind_total', 'direct']
R['mediation'] = {l: dict(est=round(est[i], 4),
                          ci_iid=np.percentile(Bi[:, i], [2.5, 97.5]).round(4).tolist(),
                          ci_block=np.percentile(Bb[:, i], [2.5, 97.5]).round(4).tolist()) for i, l in enumerate(lab)}
print('mediation', R['mediation'])

# H3 interaction: naive OLS vs cluster-robust (2-line clusters) vs band fixed effects
f = 'EVI_z~ph_z*lNTL_z'
m0 = smf.ols(f, d).fit(); m1 = smf.ols(f, d).fit(cov_type='cluster', cov_kwds={'groups': d.cl2})
m2 = smf.ols(f + '+C(band)', d).fit(cov_type='cluster', cov_kwds={'groups': d.cl2})
d2 = d.join(pd.DataFrame(StandardScaler().fit_transform(df[SOIL]), columns=[s + '_z' for s in SOIL]))
fcov = f + '+' + '+'.join(s + '_z' for s in SOIL if s not in ('phh2o', 'silt'))
m3 = smf.ols(fcov, d2).fit(cov_type='cluster', cov_kwds={'groups': d2.cl2})
k = 'ph_z:lNTL_z'
R['h3'] = {nm: dict(b=round(m.params[k], 4), se=round(m.bse[k], 4), p=float(m.pvalues[k]))
           for nm, m in [('ols', m0), ('cluster', m1), ('cluster_bandFE', m2), ('cluster_soilcov', m3)]}
R['n_clusters'] = int(d.cl2.nunique())
# tercile slopes, block-bootstrap CI of high-minus-low difference
d['tier'] = pd.qcut(df.NTL, 3, labels=['low', 'mid', 'high'])
def sl(s): return smf.ols('EVI~ph', s).fit().params['ph']
def dsl(s): return sl(s[s.tier == 'high']) - sl(s[s.tier == 'low'])
Bd = block_boot(dsl, d, 2 * period, NBOOT)
R['h3_tercile'] = dict(low=round(sl(d[d.tier == 'low']), 4), high=round(sl(d[d.tier == 'high']), 4),
                       diff=round(dsl(d), 4), ci_block=np.percentile(Bd, [2.5, 97.5]).round(4).tolist())
print('h3', R['h3'], R['h3_tercile'])

# pH breakpoint: block-bootstrap CI and leave-one-band-out stability
def seg_bp(x, yy):
    grid = np.quantile(x, np.linspace(.05, .95, 181)); best = (None, np.inf)
    for c in grid:
        X = np.column_stack([np.ones_like(x), x, np.maximum(x - c, 0)])
        rss = ((yy - X @ np.linalg.lstsq(X, yy, rcond=None)[0]) ** 2).sum()
        if rss < best[1]: best = (c, rss)
    return best[0]
bp = seg_bp(df.phh2o.values, y)
Bbp = block_boot(lambda s: seg_bp(s.ph.values, s.EVI.values), d, 2 * period, min(NBOOT, 500))
lobo = [seg_bp(df.phh2o.values[band != b], y[band != b]) for b in range(K)]
R['bp_ph'] = dict(bp=round(float(bp), 3), ci_block=np.percentile(Bbp, [2.5, 97.5]).round(3).tolist(),
                  lobo_range=[round(min(lobo), 3), round(max(lobo), 3)])
print('bp', R['bp_ph'])

# ---------------------------------------------------------------- 4. ALE vs PDP
def ale_1d(model, X, feat, bins=40):
    x = X[feat].values; q = np.unique(np.quantile(x, np.linspace(0.01, 0.99, bins + 1)))
    zi = np.clip(np.searchsorted(q, x, side='right') - 1, 0, len(q) - 2); eff = np.zeros(len(q) - 1)
    for j in range(len(q) - 1):
        m = zi == j
        if m.sum() == 0: continue
        lo, hi = X[m].copy(), X[m].copy(); lo[feat] = q[j]; hi[feat] = q[j + 1]
        eff[j] = (model.predict(hi) - model.predict(lo)).mean()
    acc = np.concatenate([[0], np.cumsum(eff)]); cnt = np.bincount(zi, minlength=len(q) - 1)
    centre = np.sum((acc[:-1] + acc[1:]) / 2 * cnt) / cnt.sum()
    return q, acc - centre
from sklearn.inspection import partial_dependence
model = rf(5).fit(Xf, y); ale = {}
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
B_, O_, INK, MUTE, GRID = '#2a78d6', '#eb6834', '#0b0b0b', '#52514e', '#dddcd6'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': .6, 'savefig.dpi': 300})
fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.4))
labels = {'soc': 'Soil organic carbon (g kg$^{-1}$)', 'phh2o': 'Soil pH (H$_2$O)',
          'NTL': 'Nighttime radiance (nW cm$^{-2}$ sr$^{-1}$)', 'bdod': 'Bulk density (g cm$^{-3}$)'}
for ax, v, l in zip(axs.flat, ['soc', 'phh2o', 'NTL', 'bdod'], 'abcd'):
    q, a = ale_1d(model, Xf, v); ale[v] = dict(range=round(float(a.max() - a.min()), 4))
    pdp = partial_dependence(model, Xf, [v], grid_resolution=50, percentiles=(0.02, 0.98), kind='average')
    pv = pdp['average'][0] - pdp['average'][0].mean()
    ax.plot(pdp['grid_values'][0], pv, color=MUTE, lw=1.2, ls='--', label='Partial dependence (centred)')
    ax.plot(q, a, color=B_, lw=2, label='Accumulated local effect')
    ale[v]['pdp_range'] = round(float(pv.max() - pv.min()), 4)
    if v == 'phh2o': ax.axvline(bp, color=O_, lw=1, ls=':')
    for qq in np.quantile(df[v], np.linspace(.1, .9, 9)): ax.plot([qq, qq], [0, .03], transform=ax.get_xaxis_transform(), color=INK, lw=.8)
    if v == 'NTL':
        ax.set_xscale('log'); ax.set_xticks([0.3, 0.5, 1, 2, 4]); ax.set_xticklabels(['0.3', '0.5', '1', '2', '4']); ax.minorticks_off()
    ax.set_xlabel(labels[v]); ax.set_ylabel('Effect on predicted EVI'); ax.text(-.14, 1.03, l, transform=ax.transAxes, fontweight='bold', fontsize=11)
axs[0, 0].legend(frameon=False, fontsize=7)
plt.tight_layout(); plt.savefig('figs/fig11_ale.png'); plt.close()
R['ale'] = ale

# figure: validation hierarchy incl. geographic bands
fig, ax = plt.subplots(figsize=(7.2, 2.9))
names = [('random', 'Random\n10-fold'), ('feature', 'Feature-space\nblocks'), ('band0', 'Latitude\nbands'),
         ('band1', 'Bands +\n0.5 km buffer'), ('band2', 'Bands +\n1 km buffer')]
xs = np.arange(len(names)); w = .38
for off, tag, col, lb in [(-w / 2, 'full', B_, 'Fully grown trees'), (w / 2, 'reg', O_, 'Min. leaf size 20')]:
    vals = [cv[f'{k}_{tag}']['R2'] for k, _ in names]
    bb = ax.bar(xs + off, vals, w * .95, color=col, label=lb)
    for b_, v_ in zip(bb, vals): ax.text(b_.get_x() + b_.get_width() / 2, max(v_, 0) + .008, f'{v_:.2f}', ha='center', fontsize=7)
ax.axhline(0, color=INK, lw=.8); ax.set_xticks(xs, [n_ for _, n_ in names], fontsize=8)
ax.set_ylabel('Cross-validated R$^2$'); ax.legend(frameon=False, fontsize=7.5); ax.grid(axis='x', visible=False)
plt.tight_layout(); plt.savefig('figs/fig8b_geocv.png'); plt.close()

json.dump(R, open('results/R_scan.json', 'w'), indent=1, default=float)

# ---------------------------------------------------------------- 5. LaTeX macros
def f3(x): return f'{x:.3f}'.replace('-', '\\ensuremath{-}')
def ci(c, nd=3): return f'{c[0]:.{nd}f} to {c[1]:.{nd}f}'.replace('-', '\\ensuremath{-}')
def pfmt(p): return '< 0.001' if p < 0.001 else f'= {p:.3f}'
M = {
 'scanPeriod': str(period), 'scanLines': f"{R['scan']['n_lines']:.0f}",
 'residLagOne': f3(R['resid_acf']['lag1']), 'residRangeKm': f"{R['resid_acf']['range_km']:.1f}",
 'nEff': f"{R['n_eff_ar1']:,}", 'moranRow': f3(R['moran_row']),
 'cvRandom': f3(cv['random_full']['R2']), 'cvFeature': f3(cv['feature_full']['R2']),
 'cvBand': f3(cv['band0_full']['R2']), 'cvBandBufA': f3(cv['band1_full']['R2']), 'cvBandBufB': f3(cv['band2_full']['R2']),
 'cvRandomReg': f3(cv['random_reg']['R2']), 'cvFeatureReg': f3(cv['feature_reg']['R2']),
 'cvBandReg': f3(cv['band0_reg']['R2']), 'cvBandBufAReg': f3(cv['band1_reg']['R2']), 'cvBandBufBReg': f3(cv['band2_reg']['R2']),
 'rmseBandBufB': f"{cv['band2_full']['RMSE']:.4f}", 'rmseBandBufBReg': f"{cv['band2_reg']['RMSE']:.4f}",
 'vpBandFull': f3(vp['full']), 'vpBandSoil': f3(vp['soil']), 'vpBandNtl': f3(vp['ntl']), 'vpBandUnique': f3(vp['unique_ntl']),
 'medIndBlock': ci(R['mediation']['ind_total']['ci_block']), 'medIndIid': ci(R['mediation']['ind_total']['ci_iid']),
 'medInd': f3(R['mediation']['ind_total']['est']), 'medDir': f3(R['mediation']['direct']['est']),
 'medDirBlock': ci(R['mediation']['direct']['ci_block']),
 'hThreeOLSp': pfmt(R['h3']['ols']['p']), 'hThreeClusterB': f3(R['h3']['cluster']['b']),
 'hThreeClusterP': pfmt(R['h3']['cluster']['p']), 'hThreeFEB': f3(R['h3']['cluster_bandFE']['b']),
 'hThreeFEP': pfmt(R['h3']['cluster_bandFE']['p']), 'hThreeCovB': f3(R['h3']['cluster_soilcov']['b']),
 'hThreeCovP': pfmt(R['h3']['cluster_soilcov']['p']), 'nClusters': str(R['n_clusters']),
 'slopeDiff': f3(R['h3_tercile']['diff']), 'slopeDiffCI': ci(R['h3_tercile']['ci_block']),
 'bpPh': f"{R['bp_ph']['bp']:.2f}", 'bpPhBlockCI': ci(R['bp_ph']['ci_block'], 2), 'bpPhLobo': ci(R['bp_ph']['lobo_range'], 2),
 'aleSocRange': f"{ale['soc']['range']:.3f}", 'pdpSocRange': f"{ale['soc']['pdp_range']:.3f}",
 'alePhRange': f"{ale['phh2o']['range']:.3f}", 'aleNtlRange': f"{ale['NTL']['range']:.3f}",
}
with open('results/macros_scan.tex', 'w') as fh:
    fh.write('% auto-generated by scripts/robustness_scan.py -- do not edit by hand\n')
    for k_, v_ in M.items(): fh.write(f'\\newcommand{{\\{k_}}}{{{v_}}}\n')
print('done')
