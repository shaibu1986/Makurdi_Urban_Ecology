"""
urban_filter_tests.py
Reproduces the coverage audit, validation designs, permutation importance, variance
partitioning, multiple-mediator model, gradient-dependent coupling and segmented
regressions reported in the resubmitted manuscript (Tables 2-5; Figs. 2, 3, 5, 8-12).

Usage (from repository root):  python scripts/urban_filter_tests.py
Requires: pandas, numpy, scikit-learn, statsmodels, scipy, matplotlib
Outputs:  results/*.json and figs/*.png  (runtime ~20-25 min on 4 cores; bootstrap steps dominate)
"""
import os
os.makedirs('results', exist_ok=True); os.makedirs('figs', exist_ok=True)
RAW = 'data/Makurdi_Full_Suite_EVI_Data.csv'

# ==================== a3.py ====================
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_predict
from sklearn.metrics import r2_score
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
df=pd.read_csv('data/Makurdi_Full_Suite_EVI_Data.csv').dropna().reset_index(drop=True)
soil=['cec','bdod','phh2o','soc','nitrogen','sand','silt','clay']
y=df.EVI.values
R={}
# 1 PCA
Zs=StandardScaler().fit_transform(df[soil]); pca=PCA().fit(Zs)
R['pca_var']=pca.explained_variance_ratio_.round(3).tolist()
load=pd.DataFrame(pca.components_[:3].T,index=soil,columns=['PC1','PC2','PC3']).round(3); print(load); print(R['pca_var'])
pcs=pca.transform(Zs)[:,:3]; 
for i in range(3): df[f'PC{i+1}']=pcs[:,i]
print(df[['PC1','PC2','PC3','NTL','EVI']].corr().round(3))
# 2 variance partition
kf=KFold(10,shuffle=True,random_state=42)
g=KMeans(10,random_state=42,n_init=10).fit_predict(Zs)
def rfcv(cols,cv='r'):
    rf=RandomForestRegressor(n_estimators=500,random_state=42,n_jobs=-1)
    if cv=='r': p=cross_val_predict(rf,df[cols],y,cv=kf)
    else: p=cross_val_predict(rf,df[cols],y,cv=GroupKFold(10),groups=g)
    return r2_score(y,p)
vp={}
for cv in ['r','b']:
    full=rfcv(['NTL']+soil,cv); s=rfcv(soil,cv); u=rfcv(['NTL'],cv)
    vp[cv]=dict(full=full,soil=s,ntl=u,unique_ntl=full-s,unique_soil=full-u,shared=s+u-full)
def ols_r2(cols):
    m=sm.OLS(y,sm.add_constant(df[cols])).fit(); return m.rsquared_adj
f=ols_r2(['NTL']+soil); s=ols_r2(soil); u=ols_r2(['NTL'])
vp['ols']=dict(full=f,soil=s,ntl=u,unique_ntl=f-s,unique_soil=f-u,shared=s+u-f)
R['vp']={k:{a:round(b,3) for a,b in v.items()} for k,v in vp.items()}; print(R['vp'])
# 3 NTL -> soil
ntl_soil={}
for v in soil+['PC1','PC2']:
    lin=np.corrcoef(df.NTL,df[v])[0,1]**2
    rf=RandomForestRegressor(n_estimators=300,random_state=42,n_jobs=-1,min_samples_leaf=5)
    p=cross_val_predict(rf,df[['NTL']],df[v],cv=kf); ntl_soil[v]=(round(lin,3),round(r2_score(df[v],p),3))
R['ntl_soil']=ntl_soil; print(ntl_soil)
# log NTL
df['lNTL']=np.log(df.NTL)
print('logNTL corr', df[['lNTL']+soil+['EVI']].corr()['lNTL'].round(3).to_dict())
json.dump(R,open('results/R1.json','w'),default=str,indent=1)
df.to_csv('results/df_pcs.csv',index=False)

# ==================== a4.py ====================
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_predict
from sklearn.metrics import r2_score
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm, statsmodels.formula.api as smf
df=pd.read_csv('results/df_pcs.csv'); soil=['cec','bdod','phh2o','soc','nitrogen','sand','silt','clay']
y=df.EVI.values; kf=KFold(10,shuffle=True,random_state=42)
R={}
# RF partition with regularised leaves
def rfcv(cols,cv,g=None):
    rf=RandomForestRegressor(n_estimators=500,min_samples_leaf=20,random_state=42,n_jobs=-1)
    p=cross_val_predict(rf,df[cols],y,cv=cv,groups=g); return r2_score(y,p)
g=KMeans(10,random_state=42,n_init=10).fit_predict(StandardScaler().fit_transform(df[soil]))
for nm,cv,gg in [('r',kf,None),('b',GroupKFold(10),g)]:
    f=rfcv(['NTL']+soil,cv,gg); s=rfcv(soil,cv,gg); u=rfcv(['NTL'],cv,gg)
    R['vp_'+nm]=dict(full=round(f,3),soil=round(s,3),ntl=round(u,3),unique_ntl=round(f-s,3),unique_soil=round(f-u,3),shared=round(s+u-f,3))
print(R)
# mediation: standardized, via PC1-3
d=df.copy(); 
for c in ['EVI','lNTL','PC1','PC2','PC3','soc','phh2o','bdod']: d[c+'_z']=(d[c]-d[c].mean())/d[c].std()
tot=smf.ols('EVI_z~lNTL_z',d).fit(); dirm=smf.ols('EVI_z~lNTL_z+PC1_z+PC2_z+PC3_z',d).fit()
a=[smf.ols(f'PC{i}_z~lNTL_z',d).fit().params['lNTL_z'] for i in (1,2,3)]
b=[dirm.params[f'PC{i}_z'] for i in (1,2,3)]
R['med']=dict(total=tot.params['lNTL_z'],total_p=tot.pvalues['lNTL_z'],direct=dirm.params['lNTL_z'],direct_p=dirm.pvalues['lNTL_z'],a=a,b=b,ind=[x*z for x,z in zip(a,b)])
rng=np.random.default_rng(42); boots=[]
for _ in range(2000):
    s=d.sample(len(d),replace=True,random_state=rng.integers(1e9))
    m=smf.ols('EVI_z~lNTL_z+PC1_z+PC2_z+PC3_z',s).fit()
    ind=[smf.ols(f'PC{i}_z~lNTL_z',s).fit().params['lNTL_z']*m.params[f'PC{i}_z'] for i in (1,2,3)]
    boots.append(ind+[sum(ind),m.params['lNTL_z']])
B=np.array(boots); R['med_ci']=np.percentile(B,[2.5,97.5],axis=0).round(4).tolist()
print(R['med'],R['med_ci'])
# gradient-dependent coupling
q=pd.qcut(df.NTL,3,labels=['low','mid','high']); df['tier']=q
gc={}
for t in ['low','mid','high']:
    s=df[df.tier==t]; rf=RandomForestRegressor(n_estimators=500,min_samples_leaf=5,random_state=42,n_jobs=-1)
    p=cross_val_predict(rf,s[soil],s.EVI,cv=KFold(10,shuffle=True,random_state=42))
    gc[t]=dict(n=len(s),ntl_range=[round(s.NTL.min(),2),round(s.NTL.max(),2)],evi_mean=round(s.EVI.mean(),3),evi_sd=round(s.EVI.std(),3),soil_cv_r2=round(r2_score(s.EVI,p),3),
      r_soc=round(np.corrcoef(s.soc,s.EVI)[0,1],3),r_ph=round(np.corrcoef(s.phh2o,s.EVI)[0,1],3),r_bd=round(np.corrcoef(s.bdod,s.EVI)[0,1],3),r_pc1=round(np.corrcoef(s.PC1,s.EVI)[0,1],3),
      ols_r2=round(sm.OLS(s.EVI,sm.add_constant(s[soil])).fit().rsquared_adj,3))
R['gc']=gc; print(gc)
m=smf.ols('EVI_z~lNTL_z*PC1_z+lNTL_z*PC2_z+lNTL_z*PC3_z',d).fit(); R['inter']={k:(round(m.params[k],4),float(m.pvalues[k])) for k in m.params.index}; print(R['inter'])
json.dump(R,open('results/R2.json','w'),default=float,indent=1)

# ==================== a5.py ====================
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score
import statsmodels.api as sm
from scipy import stats
df=pd.read_csv('results/df_pcs.csv'); soil=['cec','bdod','phh2o','soc','nitrogen','sand','silt','clay']
df['tier']=pd.qcut(df.NTL,3,labels=['low','mid','high'])
R={}
# soil variance per tier
R['sd_tier']=df.groupby('tier')[soil+['PC1','EVI']].std().round(3).to_dict()
print(pd.DataFrame(R['sd_tier']))
# Fisher z tests low vs high
lo=df[df.tier=='low']; hi=df[df.tier=='high']
def fz(v):
    r1=np.corrcoef(lo[v],lo.EVI)[0,1]; r2=np.corrcoef(hi[v],hi.EVI)[0,1]
    z=(np.arctanh(r2)-np.arctanh(r1))/np.sqrt(1/(len(lo)-3)+1/(len(hi)-3)); return round(r1,3),round(r2,3),round(z,2),float(2*stats.norm.sf(abs(z)))
R['fz']={v:fz(v) for v in ['soc','phh2o','bdod','PC1','PC2','PC3']}; print(R['fz'])
# bootstrap OLS adj R2 difference
rng=np.random.default_rng(1); diffs=[]
for _ in range(1000):
    a=lo.sample(len(lo),replace=True,random_state=rng.integers(1e9)); b=hi.sample(len(hi),replace=True,random_state=rng.integers(1e9))
    diffs.append(sm.OLS(b.EVI,sm.add_constant(b[soil])).fit().rsquared_adj-sm.OLS(a.EVI,sm.add_constant(a[soil])).fit().rsquared_adj)
R['dR2_ci']=np.percentile(diffs,[2.5,50,97.5]).round(3).tolist(); print(R['dR2_ci'])
# grouped permutation importance on out-of-fold
X=df[['NTL']+soil]; y=df.EVI.values
groups={'Urban intensity (NTL)':['NTL'],'Organic matter/nutrients (SOC, N, CEC)':['soc','nitrogen','cec'],'Texture (sand, silt, clay)':['sand','silt','clay'],'Bulk density':['bdod'],'pH':['phh2o']}
single={c:[c] for c in X.columns}
kf=KFold(10,shuffle=True,random_state=42); gi={k:[] for k in groups}; si={k:[] for k in single}
for tr,te in kf.split(X):
    rf=RandomForestRegressor(n_estimators=500,random_state=42,n_jobs=-1).fit(X.iloc[tr],y[tr])
    base=r2_score(y[te],rf.predict(X.iloc[te]))
    for D,out in [(groups,gi),(single,si)]:
        for k,cols in D.items():
            sc=[]
            for rep in range(5):
                Xp=X.iloc[te].copy(); idx=np.random.default_rng(rep).permutation(len(Xp))
                Xp[cols]=Xp[cols].values[idx]; sc.append(base-r2_score(y[te],rf.predict(Xp)))
            out[k].append(np.mean(sc))
R['gperm']={k:(round(np.mean(v),3),round(np.std(v),3)) for k,v in gi.items()}
R['sperm']={k:(round(np.mean(v),3),round(np.std(v),3)) for k,v in si.items()}
print(R['gperm']); print(R['sperm'])
json.dump(R,open('results/R3.json','w'),default=float,indent=1)

# ==================== a6.py ====================
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
df=pd.read_csv('results/df_pcs.csv'); df['tier']=pd.qcut(df.NTL,3,labels=['low','mid','high'])
R={}
m=smf.ols('EVI~phh2o*C(tier)',df).fit(); R['ph_slopes']={k:(round(v,4),float(m.pvalues[k])) for k,v in m.params.items()}; print(R['ph_slopes'])
for t in ['low','mid','high']:
    s=df[df.tier==t]; mm=smf.ols('EVI~phh2o',s).fit(); print(t,round(mm.params['phh2o'],4),mm.conf_int().loc['phh2o'].round(4).tolist())
    R['ph_'+t]=[mm.params['phh2o']]+mm.conf_int().loc['phh2o'].tolist()
# segmented regression
def seg(x,y,grid):
    best=None
    for c in grid:
        X=np.column_stack([np.ones_like(x),x,np.maximum(x-c,0)]); b,res,*_=np.linalg.lstsq(X,y,rcond=None)
        rss=((y-X@b)**2).sum()
        if best is None or rss<best[1]: best=(c,rss,b)
    return best
out={}
for v,tr in [('soc',None),('NTL','log'),('phh2o',None),('bdod',None)]:
    x=df[v].values.astype(float); x2=np.log(x) if tr else x; y=df.EVI.values
    grid=np.quantile(x2,np.linspace(.05,.95,181))
    c,rss,b=seg(x2,y,grid)
    X1=np.column_stack([np.ones_like(x2),x2]); b1=np.linalg.lstsq(X1,y,rcond=None)[0]; rss1=((y-X1@b1)**2).sum()
    n=len(y); F=((rss1-rss)/2)/(rss/(n-4)); 
    from scipy import stats; pF=stats.f.sf(F,2,n-4)
    aic_lin=n*np.log(rss1/n)+2*2; aic_seg=n*np.log(rss/n)+2*4
    rng=np.random.default_rng(7); bs=[]
    for _ in range(500):
        i=rng.integers(0,n,n); bs.append(seg(x2[i],y[i],grid)[0])
    ci=np.percentile(bs,[2.5,97.5])
    back=lambda z: float(np.exp(z)) if tr else float(z)
    out[v]=dict(bp=back(c),ci=[back(ci[0]),back(ci[1])],slope_before=float(b[1]),slope_after=float(b[1]+b[2]),F=float(F),p=float(pF),dAIC=float(aic_lin-aic_seg),median=float(np.median(x)))
    print(v,{k:(np.round(val,4) if not isinstance(val,list) else np.round(val,3).tolist()) for k,val in out[v].items()})
R['seg']=out; json.dump(R,open('results/R4.json','w'),default=float,indent=1)

# ==================== figs.py ====================
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_predict
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
B,O,A='#2a78d6','#eb6834','#1baf7a'; INK='#0b0b0b'; MUTE='#52514e'; GRID='#dddcd6'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':MUTE,'axes.labelcolor':INK,'xtick.color':MUTE,'ytick.color':MUTE,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,'savefig.dpi':300})
raw=pd.read_csv('data/Makurdi_Full_Suite_EVI_Data.csv'); miss=raw[['cec','soc']].isna().any(axis=1)
df=pd.read_csv('results/df_pcs.csv'); soil=['cec','bdod','phh2o','soc','nitrogen','sand','silt','clay']
R2=json.load(open('results/R2.json')); R3=json.load(open('results/R3.json')); R4=json.load(open('results/R4.json'))
def lab(ax,t): ax.text(-0.12,1.04,t,transform=ax.transAxes,fontweight='bold',fontsize=11,color=INK)
# FIG 5 coverage
fig,ax=plt.subplots(1,2,figsize=(7.2,3.0))
bins=np.logspace(np.log10(0.25),np.log10(8),30)
for sel,c,l in [(~miss,B,f'Retained (n = {int((~miss).sum()):,})'),(miss,O,f'Excluded, soil no-data (n = {int(miss.sum())})')]:
    v=np.sort(raw.NTL[sel].dropna().values); ax[0].step(v,np.arange(1,len(v)+1)/len(v),where='post',color=c,lw=2,label=l)
ax[0].set_xscale('log'); ax[0].set_xticks([0.3,0.5,1,2,4,7],['0.3','0.5','1','2','4','7']); ax[0].minorticks_off()
ax[0].set_xlabel('Nighttime radiance, nW cm$^{-2}$ sr$^{-1}$ (log scale)'); ax[0].set_ylabel('Cumulative proportion of cells'); ax[0].legend(frameon=False,fontsize=7.5,loc='lower right'); lab(ax[0],'a')
th=[(0,0.5,'≤0.5'),(0.5,1,'0.5–1'),(1,2,'1–2'),(2,4,'2–4'),(4,99,'>4')]
sh=[miss[(raw.NTL>a)&(raw.NTL<=b)].mean()*100 for a,b,_ in th]; ns=[((raw.NTL>a)&(raw.NTL<=b)).sum() for a,b,_ in th]
bars=ax[1].bar([t[2] for t in th],sh,color=O,width=.62)
for bb,s,n in zip(bars,sh,ns): ax[1].text(bb.get_x()+bb.get_width()/2,s+1.2,f'{s:.0f}%\n(n={n})',ha='center',fontsize=7,color=INK)
ax[1].set_ylim(0,75); ax[1].set_xlabel('Nighttime radiance class'); ax[1].set_ylabel('Cells lacking SoilGrids values (%)'); ax[1].grid(axis='x',visible=False); lab(ax[1],'b')
plt.tight_layout(); plt.savefig('figs/fig5_coverage.png'); plt.close()
# FIG 8 validation
X=df[['NTL']+soil]; y=df.EVI.values
rf=RandomForestRegressor(n_estimators=1000,random_state=42,n_jobs=-1)
g=KMeans(10,random_state=42,n_init=10).fit_predict(StandardScaler().fit_transform(df[soil]))
pa=rf.fit(X,y).predict(X)
pr=cross_val_predict(rf,X,y,cv=KFold(10,shuffle=True,random_state=42)); pb=cross_val_predict(rf,X,y,cv=GroupKFold(10),groups=g)
fig,ax=plt.subplots(1,3,figsize=(7.4,2.7),sharex=True,sharey=True)
for a,p,t,c,l in zip(ax,[pa,pr,pb],['Apparent (in-sample)','Random 10-fold CV','Feature-space blocked CV'],[MUTE,B,O],'abc'):
    a.scatter(y,p,s=3,alpha=.35,color=c,linewidths=0); a.plot([-.2,.55],[-.2,.55],color=INK,lw=.8,ls='--')
    a.set_title(f'{t}\nR² = {r2_score(y,p):.3f}',fontsize=8.5,color=INK); a.set_xlabel('Observed EVI'); lab(a,l)
ax[0].set_ylabel('Predicted EVI'); ax[0].set_xlim(-.2,.55); ax[0].set_ylim(-.2,.55)
plt.tight_layout(); plt.savefig('figs/fig8_validation.png'); plt.close()
print('R2s',r2_score(y,pa),r2_score(y,pr),r2_score(y,pb))
# FIG 9 permutation importance
names={'NTL':'NTL','cec':'CEC','bdod':'Bulk density','phh2o':'pH','soc':'SOC','nitrogen':'Total N','sand':'Sand','silt':'Silt','clay':'Clay'}
sp=sorted(R3['sperm'].items(),key=lambda kv:kv[1][0]); gp=sorted(R3['gperm'].items(),key=lambda kv:kv[1][0])
fig,ax=plt.subplots(1,2,figsize=(7.4,3.2),gridspec_kw=dict(wspace=0.75))
for a,items,l,t in [(ax[0],sp,'a','Single predictors'),(ax[1],gp,'b','Predictor groups')]:
    lbls=[names.get(k,k).replace(' (','\n(') for k,_ in items]; m=[v[0] for _,v in items]; s=[v[1] for _,v in items]
    cols=[O if ('NTL' in k) else B for k,_ in items]
    a.barh(lbls,m,xerr=s,color=cols,height=.6,error_kw=dict(ecolor=MUTE,lw=.8,capsize=2)); a.set_xlabel('Drop in out-of-fold R²\nwhen permuted'); a.set_title(t,fontsize=9,color=INK); a.grid(axis='y',visible=False); lab(a,l)
ax[1].tick_params(axis='y',labelsize=7.5)
plt.subplots_adjust(left=0.13,right=0.97,bottom=0.2,top=0.9); plt.savefig('figs/fig9_permutation.png',bbox_inches='tight'); plt.close()
# FIG 10 partition + mediation
fig,ax=plt.subplots(1,2,figsize=(7.4,3.0),gridspec_kw=dict(width_ratios=[1,1.25]))
vr,vb=R2['vp_r'],R2['vp_b']; xs=np.arange(3); w=.36
vals_r=[vr['full'],vr['soil'],vr['unique_ntl']]; vals_b=[vb['full'],vb['soil'],vb['unique_ntl']]
b1=ax[0].bar(xs-w/2-.01,vals_r,w,color=B,label='Random CV'); b2=ax[0].bar(xs+w/2+.01,vals_b,w,color=O,label='Feature-space blocked CV')
for bs in (b1,b2):
    for bb in bs: ax[0].text(bb.get_x()+bb.get_width()/2,bb.get_height()+.006,f'{bb.get_height():.3f}',ha='center',fontsize=7,color=INK)
ax[0].set_xticks(xs,['NTL + soil','Soil only','Unique NTL\n(full − soil)'],fontsize=8); ax[0].set_ylabel('Cross-validated R²'); ax[0].legend(frameon=False,fontsize=7.5); ax[0].grid(axis='x',visible=False); ax[0].set_ylim(0,.35); lab(ax[0],'a')
med=R2['med']; ci=np.array(R2['med_ci'])
labels=['Indirect via PC1\n(texture–carbon axis)','Indirect via PC2\n(pH–silt axis)','Indirect via PC3\n(clay axis)','Total indirect','Direct (NTL → EVI)']
est=med['ind']+[sum(med['ind']),med['direct']]
yy=np.arange(len(est))[::-1]
for yi,e,lo,hi in zip(yy,est,ci[0],ci[1]):
    c=MUTE if lo<0<hi else (O if e<0 else B)
    ax[1].plot([lo,hi],[yi,yi],color=c,lw=2); ax[1].plot(e,yi,'o',ms=7,color=c,mec='white',mew=1.2)
ax[1].axvline(0,color=INK,lw=.8); ax[1].set_yticks(yy,labels,fontsize=7.5); ax[1].set_xlabel('Standardized effect of log NTL on EVI (95% CI)'); ax[1].grid(axis='y',visible=False); lab(ax[1],'b')
plt.tight_layout(); plt.savefig('figs/fig10_partition_mediation.png'); plt.close()
# FIG 12 pH coupling + breakpoints
df['tier']=pd.qcut(df.NTL,3,labels=['Low NTL (0.28–0.39)','Mid NTL (0.39–0.52)','High NTL (0.52–6.40)'])
fig,ax=plt.subplots(1,3,figsize=(7.6,2.8))
for t,c in zip(df.tier.cat.categories,[A,B,O]):
    s=df[df.tier==t]; ax[0].scatter(s.phh2o,s.EVI,s=2,alpha=.18,color=c,linewidths=0)
    k,b0=np.polyfit(s.phh2o,s.EVI,1); xx=np.linspace(s.phh2o.quantile(.01),s.phh2o.quantile(.99),10)
    ax[0].plot(xx,k*xx+b0,color=c,lw=2,label=f'{t}: slope {k:.2f}')
ax[0].set_ylim(0.05,.4); ax[0].set_xlabel('Soil pH (H$_2$O)'); ax[0].set_ylabel('EVI'); ax[0].legend(frameon=False,fontsize=6,loc='lower left'); lab(ax[0],'a')
for a,v,xl,l in [(ax[1],'phh2o','Soil pH (H$_2$O)','b'),(ax[2],'bdod','Bulk density (g cm$^{-3}$)','c')]:
    q=pd.qcut(df[v],30,duplicates='drop'); gm=df.groupby(q).agg(x=(v,'mean'),y=('EVI','mean'))
    a.plot(gm.x,gm.y,'o',ms=4,color=B,mec='white',mew=.6,label='Binned means (30 quantiles)')
    sg=R4['seg'][v]; bp=sg['bp']; x=df[v].values; yv=df.EVI.values
    Xd=np.column_stack([np.ones_like(x),x,np.maximum(x-bp,0)]); bb=np.linalg.lstsq(Xd,yv,rcond=None)[0]
    xx=np.linspace(x.min(),x.max(),200); a.plot(xx,bb[0]+bb[1]*xx+bb[2]*np.maximum(xx-bp,0),color=O,lw=2,label='Segmented fit')
    a.axvspan(sg['ci'][0],sg['ci'][1],color=O,alpha=.15,lw=0); a.axvline(bp,color=O,lw=.8,ls='--')
    a.text(bp,a.get_ylim()[1] if False else .255,f' {bp:.3f}\n [{sg["ci"][0]:.3f}–{sg["ci"][1]:.3f}]',fontsize=7,color=INK,va='top')
    a.set_xlabel(xl); a.set_ylabel('EVI'); lab(a,l)
ax[1].set_ylim(.15,.26); ax[2].set_ylim(.15,.26); ax[1].legend(frameon=False,fontsize=6.5,loc='lower left')
plt.tight_layout(); plt.savefig('figs/fig12_ph_coupling.png'); plt.close()

# ==================== figs2.py ====================
import pandas as pd, numpy as np, json, warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import partial_dependence
B,O,A='#2a78d6','#eb6834','#1baf7a'; INK='#0b0b0b'; MUTE='#52514e'; GRID='#dddcd6'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'savefig.dpi':300})
def box(ax,x,y,w,h,txt,ec,fc='white',fs=8.5,bold=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.04',ec=ec,fc=fc,lw=1.4))
    ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=fs,color=INK,fontweight='bold' if bold else 'normal',wrap=True)
def arr(ax,x1,y1,x2,y2,c=INK,ls='-',lw=1.6,rad=0):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=12,color=c,lw=lw,ls=ls,connectionstyle=f'arc3,rad={rad}'))
# FIG 2 hypotheses
fig,axs=plt.subplots(1,3,figsize=(7.4,2.9))
titles=['H1  Soil-degradation filter','H2  Geomorphic template','H3  Sensitivity amplification']
for ax,t in zip(axs,titles):
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off'); ax.set_title(t,fontsize=9,fontweight='bold',color=INK)
for ax in axs:
    box(ax,0.02,0.72,0.42,0.2,'Urban intensity\n(NTL)',O); box(ax,0.56,0.72,0.42,0.2,'Landform &\ndrainage',MUTE)
    box(ax,0.29,0.38,0.42,0.2,'Soil state\n(SoilGrids)',B); box(ax,0.29,0.04,0.42,0.2,'Canopy vigor\n(EVI)',A)
a=axs[0]; arr(a,0.23,0.72,0.40,0.58,O,lw=2.4); arr(a,0.5,0.38,0.5,0.24,INK,lw=2.4); arr(a,0.77,0.72,0.60,0.58,MUTE,ls=(0,(3,2)),lw=1)
a.text(0.5,-0.08,'Indirect path NTL→soil→EVI large',ha='center',fontsize=7.5,color=MUTE)
a=axs[1]; arr(a,0.77,0.72,0.60,0.58,MUTE,lw=2.4); arr(a,0.5,0.38,0.5,0.24,INK,lw=2.4); arr(a,0.23,0.72,0.40,0.58,O,ls=(0,(3,2)),lw=1); arr(a,0.10,0.72,0.28,0.16,O,lw=1.4,rad=0.25)
a.text(0.5,-0.08,'NTL explains little soil variance;\nindirect path ≈ 0; direct NTL effect',ha='center',fontsize=7.5,color=MUTE)
a=axs[2]; arr(a,0.77,0.72,0.60,0.58,MUTE,lw=2.4); arr(a,0.5,0.38,0.5,0.24,INK,lw=2.4)
arr(a,0.18,0.72,0.49,0.31,O,lw=1.8,rad=0.2); a.plot(0.5,0.31,'o',color=O,ms=6)
a.text(0.5,-0.08,'NTL steepens the soil→EVI slope\n(NTL × soil interaction)',ha='center',fontsize=7.5,color=MUTE)
plt.subplots_adjust(left=0.01,right=0.99,top=0.88,bottom=0.13,wspace=0.08); plt.savefig('figs/fig2_hypotheses.png',bbox_inches='tight'); plt.close()
# FIG 3 workflow
fig,ax=plt.subplots(figsize=(7.4,4.8)); ax.set_xlim(0,13); ax.set_ylim(-0.4,10.4); ax.axis('off')
st=[('1. Data fusion','Google Earth Engine: VIIRS nighttime lights (2024 median), Sentinel-2 EVI\n(2024 mean), SoilGrids 2.0 (CEC, BD, pH, SOC, N, sand, silt, clay; 0–30 cm mean)',B),
    ('2. Grid &\ncoverage audit','500 m grid (3,773 cells); cells lacking soil values compared with retained cells\nalong the NTL gradient; 3,507 analysable cells',O),
    ('3. Model &\nvalidation','Random Forest (1,000 trees); apparent vs random ten-fold vs blocked ten-fold CV;\nout-of-fold permutation importance (single and grouped predictors)',B),
    ('4. Hypothesis\ntests','H1–H3: variance partitioning (urban vs soil); multiple-mediator model via three\nsoil principal components (bootstrap CI); NTL × soil coupling (terciles, interaction)',A),
    ('5. Breakpoints\n& protocol','Segmented regression with bootstrap 95% CI; partial dependence;\nsynthesis into a four-step screening protocol for open soil data',A)]
h=1.55; gap=0.42
for i,(t,d,c) in enumerate(st):
    y=10-(i+1)*h-i*gap+0.2
    ax.add_patch(FancyBboxPatch((0.05,y),2.5,h,boxstyle='round,pad=0.02,rounding_size=0.12',ec=c,fc=c,lw=1.4))
    ax.text(1.3,y+h/2,t,ha='center',va='center',color='white',fontweight='bold',fontsize=8)
    ax.add_patch(FancyBboxPatch((2.75,y),10.2,h,boxstyle='round,pad=0.02,rounding_size=0.12',ec=c,fc='white',lw=1.4))
    ax.text(2.95,y+h/2,d,ha='left',va='center',fontsize=7.2,color=INK,linespacing=1.45)
    if i<4: arr(ax,1.3,y-0.02,1.3,y-gap+0.02,MUTE,lw=1.4)
plt.savefig('figs/fig3_workflow.png',bbox_inches='tight'); plt.close()
# FIG 11 PDP regenerated
df=pd.read_csv('results/df_pcs.csv'); soil=['cec','bdod','phh2o','soc','nitrogen','sand','silt','clay']; X=df[['NTL']+soil]; y=df.EVI
rf=RandomForestRegressor(n_estimators=1000,random_state=42,n_jobs=-1).fit(X,y)
R4=json.load(open('results/R4.json'))['seg']
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.color':GRID,'grid.linewidth':.6,'axes.edgecolor':MUTE,'xtick.color':MUTE,'ytick.color':MUTE})
fig,axs=plt.subplots(2,2,figsize=(7.2,5.4))
for ax,(v,xl,l) in zip(axs.flat,[('soc','Soil organic carbon (g kg$^{-1}$)','a'),('phh2o','Soil pH (H$_2$O)','b'),('NTL','Nighttime radiance (nW cm$^{-2}$ sr$^{-1}$)','c'),('bdod','Bulk density (g cm$^{-3}$)','d')]):
    pdp=partial_dependence(rf,X,[v],grid_resolution=100,percentiles=(0,1),kind='average')
    ax.plot(pdp['grid_values'][0],pdp['average'][0],color=B,lw=2)
    med=df[v].median(); ax.axvline(med,color=MUTE,ls=':',lw=1.2)
    sg=R4[v]
    if sg['p']<0.05:
        ax.axvspan(sg['ci'][0],sg['ci'][1],color=O,alpha=.15,lw=0); ax.axvline(sg['bp'],color=O,ls='--',lw=1.2)
    for q in np.quantile(df[v],np.linspace(.1,.9,9)): ax.plot([q,q],[0,0.03],transform=ax.get_xaxis_transform(),color=INK,lw=.8)
    ax.set_xlabel(xl); ax.set_ylabel('Partial dependence of EVI'); ax.text(-0.14,1.03,l,transform=ax.transAxes,fontweight='bold',fontsize=11)
axs[1,0].text(0.97,0.92,'No supported breakpoint\n(segmented vs linear, p = 0.41)',transform=axs[1,0].transAxes,ha='right',va='top',fontsize=7,color=INK)
from matplotlib.lines import Line2D
fig.legend([Line2D([],[],color=B,lw=2),Line2D([],[],color=MUTE,ls=':'),Line2D([],[],color=O,ls='--')],['Partial dependence','Landscape median (reference only)','Segmented-regression breakpoint (shaded: 95% CI)'],loc='lower center',ncol=3,frameon=False,fontsize=7.5)
plt.tight_layout(rect=(0,0.05,1,1)); plt.savefig('figs/fig11_pdp.png'); plt.close()
