# Changelog
## 2026-10 — EES resubmission
- Added `scripts/robustness_scan.py`: geographic (latitude-band, buffered) CV; residual correlogram, Moran's I, effective n; moving-block bootstrap; scan-line cluster-robust SEs; band fixed effects; leave-one-band-out breakpoint; ALE replaces PDP.
- Added `scripts/gee/makurdi_export_v2.js` and `scripts/robustness_geo.py` (coordinates, terrain/hydrology confounders, iSDAsoil negative control, spatial-error models).
- Added `scripts/urban_filter_tests.py` (previously referenced but missing from the repository).
- README rewritten; superseded claims (R² = 0.914 as predictive skill; medians as tipping points) withdrawn.
- Known issues documented: original EVI used `COPERNICUS/S2_SR` with scene-level cloud filter only (v2 uses `S2_SR_HARMONIZED` + SCL mask); 0–30 cm soil values are unweighted means of the three depth layers.
