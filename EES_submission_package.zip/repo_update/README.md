# Does urbanization filter vegetation through the soil? — Makurdi, Nigeria

Data and code for: **Shaibu O. & Kirichuk A.A. — "Does urbanization filter vegetation through the soil? A spatially validated test with global soil maps in a West African floodplain city"** (submitted to *Environmental Earth Sciences*).

> **Note on earlier versions of this repository.** Earlier README text reported an in-sample R² of 0.914 as "predictive power" and landscape medians (SOC 11.27 g/kg, pH 5.77) as "tipping points". Both statements are superseded: 0.914 is an apparent (in-sample) fit; cross-validated skill is 0.355 (random) and ≈0.2 (geographic), and breakpoints are now estimated by segmented regression (pH 5.83, block-bootstrap 95% CI 5.78–5.91). See CHANGELOG.md.

## Main findings
- The SoilGrids built-up mask removes 59% of cells with NTL > 4 nW cm⁻² sr⁻¹ (coverage bias).
- The soil-mediated effect of urban intensity on EVI is null (−0.010; block-bootstrap 95% CI −0.057 to 0.035); the direct effect is −0.088 → **geomorphic template, not soil-degradation filter**.
- An apparent urban amplification of the EVI–pH slope (p < 0.001 conventionally) **disappears within latitude bands** (p = 0.53); the pH breakpoint is stable.
- Residual autocorrelation → effective n ≈ 600 of 3,507 cells.

## Repository
| Path | Content |
|---|---|
| `data/Makurdi_Full_Suite_EVI_Data.csv` | 3,773 grid cells (500 m), rows in Earth Engine `coveringGrid` scan order; 266 cells lack soil values |
| `data/DATA_DICTIONARY.md` | variables, units, conversion factors |
| `scripts/GEE/Variables_Extraction` | original Earth Engine extraction |
| `scripts/gee/makurdi_export_v2.js` | re-export with centroid coordinates, terrain/hydrology, iSDAsoil, Black Marble, GHSL, cloud-masked seasonal EVI |
| `scripts/urban_filter_tests.py` | coverage audit, validation designs, permutation importance, partitioning, mediation, coupling, breakpoints (Tables 2–5; Figs 5, 7, 9, 10, 12) |
| `scripts/robustness_scan.py` | geographic band CV, residual correlogram, effective n, block bootstrap, cluster-robust SEs, band fixed effects, ALE (Tables 2, 3, 6; Figs 8, 11) |
| `scripts/robustness_geo.py` | 2-D spatial CV + AOA, urban/soil/terrain partition, iSDAsoil circularity control, spatial-error models (needs v2 export) |
| `results/` | JSON outputs and `macros_scan.tex` (numbers inserted into the LaTeX manuscript) |

## Reproduce
```bash
pip install -r requirements.txt
make all        # ~40-60 min on 2 cores
```
Random seeds are fixed (42). Small differences in the third decimal can arise from scikit-learn versions.

## License
MIT (code). Derived data follow the licences of VIIRS (NOAA/EOG), Sentinel-2 (Copernicus) and SoilGrids 2.0 (ISRIC, CC-BY 4.0).
