# Environmental Earth Sciences — submission checklist

Target: *Environmental Earth Sciences* (Springer Nature), Original Article. You can accept the Springer transfer offer from EMAS or submit directly.

## A. Must do before submitting

**Check the journal's current terms.**

1. **Fees and policies.** EES became fully open access on 1 Jan 2026 (APC ≈ USD 3,190 / EUR 2,590 / GBP 2,290, per the research report).
   - Check whether RUDN has a Springer Nature transformative agreement, or whether you qualify for a waiver.
   - If the APC is a barrier, use the same LaTeX source for *Discover Sustainability* (lower APC) or *Modeling Earth Systems and Environment* (subscription route).
2. **Author guidelines.** Re-read https://link.springer.com/journal/12665/submission-guidelines. I could not open the page from here, so these items follow standard Springer practice and need confirming:
   - abstract length;
   - number of keywords;
   - the reference style option.

**Build the submission PDF.**

3. **Compile with the official class.** On Overleaf, open "Springer Nature LaTeX Template", then:
   - upload `main.tex`, `sections/`, `figures/`, `results/` and `refs.bib`;
   - delete `sn-shim.sty`;
   - keep `\documentclass[pdflatex,sn-basic]{sn-jnl}`.

   The PDF in this package is a local preview made with a stand-in class.

**Fix the repository and archive it.**

4. **Update the GitHub repository.** Replace the README (the old one still claims "R² = 0.914 predictive power" and median "tipping points"). Push the following from `repo/`:
   - `scripts/` (including the previously missing `urban_filter_tests.py`);
   - `requirements.txt`, `Makefile`, `CHANGELOG.md`;
   - the corrected `data/DATA_DICTIONARY.md`;
   - `results/`.
5. **Archive a release on Zenodo.** Use the GitHub–Zenodo integration, then paste the DOI into `sections/06_declarations.tex` and the cover letter.

**Fix the content.**

6. **Nitrogen units.** Median N = 9.66 "g/kg" against SOC = 11.27 g/kg (C:N ≈ 1.2) is implausible; N is probably 10× too high.
   - Check the SoilGrids asset units and the conversion factor in the GEE script, then correct the data dictionary and the axis label of Fig. S1.
   - No analysis is affected: every model is scale-invariant or uses standardized inputs.
7. **Author name order.** The manuscript uses given name *Ochoche*, surname *Shaibu*, to match "Shaibu, O." in your published Springer paper. Change this if your preferred form differs.
8. **Generative-AI statement.** Edit or delete it in the Declarations to reflect what you actually used, following Springer Nature's AI policy.
9. **Overlap with your 2026 papers.**
   - Confirm that the study-area paragraph and Fig. 1 do not duplicate text or figures from *Urban Ecosystems* 29:219 or *RUDN J. Ecol. Life Saf.* 34:205–222. If they do, rephrase or cite them as "adapted from".
   - Springer runs iThenticate on every submission.
10. **Suggested reviewers.** Add 3–5 to the cover letter, with no co-authorship in the last 5 years. Look in the spatial-validation, African digital soil mapping and urban vegetation remote-sensing communities.
11. **Verify the 15 new references** (DOIs are included). For entries truncated to "and others", BibTeX prints "et al."; check the full author lists against the DOIs if the journal requires them.
12. **ORCIDs.** Enter them in the submission system; the sn-jnl class has no ORCID field.

## B. Strongly recommended: the coordinate-based extension (~1 day)

This answers the two weaknesses a reviewer is most likely to raise: no terrain or hydrology controls, and circularity shown only by argument.

1. Run `repo/scripts/gee/makurdi_export_v2.js` in the Earth Engine Code Editor; 3 export tasks, about 10–20 min. Check the asset IDs and scale factors it flags.
2. Put `Makurdi_v2_original.csv` and `Makurdi_v2_cells.csv` in `repo/data/` and run `make geo`.
3. This adds:
   - 2-D spatial CV with area of applicability;
   - the urban / soil / terrain variance partition;
   - the SOC–EVI association controlling for HAND, TWI and distance to the river;
   - the iSDAsoil negative control for circularity;
   - spatial-error models for H3;
   - alternative urban axes (GHSL built-up fraction, Black Marble);
   - dry- versus wet-season EVI.
4. Send me the two CSVs and I will write the corresponding Results subsection, table and figure into the LaTeX source. Interpretation depends on the results, so nothing has been pre-written.

## C. What changed relative to the EMAS version

- New title framed around a general question. A delta paragraph sets this paper apart from your 2026 papers.
- New spatial-robustness analysis (`robustness_scan.py`) on the archived data. The rows turned out to be in raster-scan order, which made geographic validation possible without coordinates.
- **Conclusion changed:** the H3 "urban amplification of pH sensitivity", previously the headline novelty, does not survive geographic controls (band fixed effects p = 0.53; block-bootstrap CI includes 0). It is now reported as a cautionary result. H1 rejection and the pH breakpoint are robust.
- ALE replaces PDP.
- Effective n ≈ 600 is reported.
- The screening protocol goes from 4 to 5 steps.
- Off-topic citations were removed (marine epibenthos, canal communities, antibiotic resistomes, survey sampling designs and others). 15 core methodological references were added.
- Figures renumbered. Bivariate scatter plots moved to Online Resource 1.
