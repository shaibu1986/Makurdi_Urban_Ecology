# Data dictionary — `Makurdi_Full_Suite_EVI_Data.csv`

One row per 500 m × 500 m grid cell across the Makurdi study area
(7°40′–7°53′N, 8°22′–8°42′E), Benue State, Nigeria.

- **Rows generated:** 3,773
- **Rows removed** (no-data in ≥1 layer, listwise deletion): 266
- **Rows analysed:** **3,507**

| Column | Description | Units | Source | Range in data |
|---|---|---|---|---|
| `NTL` | Night-time light radiance, 2024 annual median | nW·cm⁻²·sr⁻¹ | VIIRS DNB (VCMFG) | 0.28 – 6.40 |
| `EVI` | Enhanced Vegetation Index, 2024 mean composite (<15% cloud) | dimensionless | Sentinel-2 MSI L2A | — |
| `cec` | Cation exchange capacity, 0–30 cm mean | cmol(c)/kg | SoilGrids 2.0 | — |
| `bdod` | Bulk density, 0–30 cm mean | g/cm³ | SoilGrids 2.0 | 1.30 – 1.42 |
| `phh2o` | Soil pH (H₂O), 0–30 cm mean | pH units | SoilGrids 2.0 | 5.51 – 6.20 |
| `soc` | Soil organic carbon, 0–30 cm mean | g/kg | SoilGrids 2.0 | 8.90 – 45.16 |
| `nitrogen` | Total nitrogen, 0–30 cm mean | g/kg | SoilGrids 2.0 | — |
| `sand` | Sand fraction, 0–30 cm mean | % | SoilGrids 2.0 | — |
| `silt` | Silt fraction, 0–30 cm mean | % | SoilGrids 2.0 | — |
| `clay` | Clay fraction, 0–30 cm mean | % | SoilGrids 2.0 | — |

## Unit conversions applied

SoilGrids distributes values as scaled integers. All layers were divided by 10:

| Property | Native SoilGrids unit | Converted to |
|---|---|---|
| pH | pH × 10 | pH units |
| SOC | dg/kg | g/kg |
| Nitrogen | cg/kg | g/kg |
| CEC | mmol(c)/kg | cmol(c)/kg |

## Important notes

1. **Soil layers are model predictions, not field measurements.** SoilGrids 2.0
   is a global machine-learning product carrying regional prediction
   uncertainty. Relative spatial patterns are more reliable than absolute
   values. See Shaibu & Kirichuk (2026), *Urban Ecosystems* 29(4), 219.

2. **`sand`, `silt` and `clay` are compositional** and sum to a constant. Their
   individual model-importance scores are not independently interpretable.

3. **No coordinates are retained in this table.** This prevents geographically
   blocked cross-validation. To enable it, add grid-cell centroids to the Earth
   Engine export:

   ```python
   .map(lambda f: f.set({'lon': f.geometry().centroid().coordinates().get(0),
                         'lat': f.geometry().centroid().coordinates().get(1)}))
   ```

   then re-run `scripts/spatial_block_cv.py`, which switches to true spatial
   blocking automatically when `lon`/`lat` are present.

4. **Resolution mismatch.** SoilGrids is native 250 m and Sentinel-2 EVI is
   10–20 m; both were aggregated to the common 500 m analysis grid. No
   inference should be drawn below that support.
