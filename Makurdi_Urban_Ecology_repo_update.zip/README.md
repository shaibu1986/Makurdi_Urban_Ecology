# Makurdi Urban Ecology — Urbanization Filter Analysis

Data, code and results for:

> Shaibu, O., & Kirichuk, A. A. **Elucidating the Urbanization Filter: A
> Spatially Explicit Analysis of Edaphic Constraints and Vegetation Resilience
> along an Anthropogenic Gradient in Makurdi, Nigeria.** Submitted to
> *Environmental Monitoring and Assessment*.

Department of Human Ecology and Bioelementology, Institute of Environmental
Engineering, Peoples' Friendship University of Russia (RUDN University), Moscow.

---

## Contents

```
data/
  Makurdi_Full_Suite_EVI_Data.csv   3,507 grid cells x 10 variables
  DATA_DICTIONARY.md                columns, units, conversions, limitations
scripts/
  spatial_block_cv.py               cross-validation (Table 3)
results/
  RF_Model_Performance.csv          three evaluation designs
Geotiffs/                           spatial layer images (Figure 4)
Makurdi_Urban_Environmental_Filter_Analysis.ipynb
CHANGELOG.md
```

## Reproducing the analysis

Open the notebook in Colab (badge in cell 1) and run all cells, or locally:

```bash
pip install pandas numpy scikit-learn matplotlib seaborn
jupyter notebook Makurdi_Urban_Environmental_Filter_Analysis.ipynb
```

## Model performance

Three figures are reported, and they answer different questions:

| Evaluation design | R² | RMSE | Measures |
|---|---|---|---|
| Apparent (in-sample) | 0.914 | 0.0135 | Reproduction of data already seen — **not** predictive skill |
| Random 10-fold CV | 0.355 | 0.0369 | Interpolation within sampled conditions |
| Blocked 10-fold CV | 0.144 | 0.0425 | Extrapolation to withheld landscape units |

The apparent value is reported for transparency only. Predictive accuracy
within Makurdi is described by the random-fold value; the blocked value is the
expectation for transfer to another Guinea-Savannah city.

## Key results

- **n = 3,507** grid cells (3,773 generated; 266 removed for no-data values).
- Soil Organic Carbon ranks first in Gini importance (0.290), roughly three
  times any other predictor.
- Urbanisation shows a geochemical signature: NTL correlates positively with pH
  (r = 0.249) and bulk density (r = 0.234), negatively with CEC (r = −0.253).
- **SOC correlates negatively with EVI (r = −0.443).** Importance rank conveys
  no directional information; see manuscript Section 4.3 and `CHANGELOG.md`.

## Caveats

Soil layers are SoilGrids 2.0 **predictions, not field measurements**. Sand,
silt and clay are compositional. Coordinates are not retained, so blocked
cross-validation uses covariate-space blocks; see `data/DATA_DICTIONARY.md`.

## Licence

See `LICENSE`.
