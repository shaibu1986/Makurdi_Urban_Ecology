"""
Spatially blocked cross-validation for the Makurdi urbanization-filter model.

WHY THIS EXISTS
---------------
The published notebook fits the Random Forest to all 3,507 observations and then
scores it on those same observations:

    rf.fit(X, y); y_pred = rf.predict(X); r2_score(y, y_pred)   # -> 0.914

That is an apparent (in-sample) goodness-of-fit statistic, not a measure of
predictive skill. This script reports three figures that answer three different
questions, and writes them to a CSV you can cite directly.

WHAT YOU NEED TO ADD
--------------------
The archived table (data/Makurdi_Full_Suite_EVI_Data.csv) has no coordinates, so
true spatial blocking cannot be run from the public repository. Export the grid
centroids from Earth Engine alongside the predictors -- in your GEE export, add:

    .map(lambda f: f.set({'lon': f.geometry().centroid().coordinates().get(0),
                          'lat': f.geometry().centroid().coordinates().get(1)}))

so the CSV gains 'lon' and 'lat' columns. Then run this script. If those columns
are absent it falls back to covariate-space blocking and says so.

USAGE
-----
    pip install pandas numpy scikit-learn
    python spatial_block_cv.py [path/to/data.csv]
"""

import sys
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold, KFold, cross_val_predict
from sklearn.preprocessing import StandardScaler

CSV = sys.argv[1] if len(sys.argv) > 1 else "Makurdi_Full_Suite_EVI_Data.csv"
TARGET = "evi"
N_BLOCKS = 10
SEED = 42

# Match the published model exactly: 1000 trees, unlimited depth.
make_model = lambda: RandomForestRegressor(
    n_estimators=1000, random_state=SEED, n_jobs=-1
)


def score(y_true, y_pred, label, question):
    r2 = r2_score(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred) ** 0.5
    print(f"  {label:<46s} R2 = {r2:6.3f}   RMSE = {rmse:.4f}")
    return {"design": label, "question": question,
            "R2": round(r2, 3), "RMSE": round(rmse, 4)}


def main():
    df = pd.read_csv(CSV).dropna()
    df.columns = df.columns.str.lower()

    coord_cols = [c for c in ("lon", "lat", "longitude", "latitude", "x", "y")
                  if c in df.columns]
    has_coords = len(coord_cols) >= 2
    coord_cols = coord_cols[:2]

    X = df.drop(columns=[TARGET] + coord_cols)
    y = df[TARGET]
    print(f"Loaded {len(df):,} observations, {X.shape[1]} predictors: "
          f"{', '.join(X.columns)}\n")

    rows = []

    # 1. Apparent fit -- reproduces the published 0.914
    rows.append(score(y, make_model().fit(X, y).predict(X),
                      "Apparent (in-sample)",
                      "How closely can the model reproduce data it has seen?"))

    # 2. Random k-fold -- interpolation
    rows.append(score(y, cross_val_predict(
        make_model(), X, y, cv=KFold(N_BLOCKS, shuffle=True, random_state=SEED),
        n_jobs=-1),
        f"Random {N_BLOCKS}-fold CV",
        "Interpolation within the sampled range of conditions."))

    # 3. Blocked -- extrapolation
    if has_coords:
        basis = df[coord_cols].to_numpy()
        label = f"Spatially blocked {N_BLOCKS}-fold CV"
        print(f"\n  [spatial blocking on {coord_cols[0]}/{coord_cols[1]}]")
    else:
        soil = [c for c in X.columns if c != "ntl"]
        basis = StandardScaler().fit_transform(df[soil])
        label = f"Covariate-blocked {N_BLOCKS}-fold CV (no coordinates)"
        print("\n  [!] No coordinate columns found -- falling back to "
              "covariate-space blocking.\n      Add 'lon'/'lat' for true "
              "spatial blocking; see the docstring.")

    blocks = KMeans(n_clusters=N_BLOCKS, random_state=SEED,
                    n_init=10).fit_predict(basis)
    sizes = np.bincount(blocks)
    print(f"  block sizes: min={sizes.min()}, max={sizes.max()}, "
          f"median={int(np.median(sizes))}\n")

    rows.append(score(y, cross_val_predict(
        make_model(), X, y, cv=GroupKFold(n_splits=N_BLOCKS),
        groups=blocks, n_jobs=-1),
        label,
        "Extrapolation to landscape units absent from training."))

    out = pd.DataFrame(rows)
    out.to_csv("Model_Performance_Validated.csv", index=False)
    print("\nWritten: Model_Performance_Validated.csv")
    print("\nReport the apparent value only if you label it as such. The "
          "random-fold value\nis the honest figure for accuracy within Makurdi; "
          "the blocked value is the\nexpectation for transfer to another city.")


if __name__ == "__main__":
    main()
