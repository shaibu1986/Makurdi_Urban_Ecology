# Changelog

## [2.0] — Corrections applied during peer review

This release corrects two errors in the original analysis and brings the
repository into agreement with the revised manuscript. **The underlying data
are unchanged**; the corrections concern how results were computed and
described.

### Corrected — model evaluation

The previous notebook fitted the Random Forest to all 3,507 observations and
scored it on those same observations:

```python
rf.fit(X, y); y_pred = rf.predict(X); r2_score(y, y_pred)   # -> 0.914
```

This is an **apparent (in-sample) goodness-of-fit statistic, not a measure of
predictive skill**, and it was reported as "VALIDATED METRICS". Random Forests
grown to full depth interpolate their training data closely, so the value is
high by construction.

The notebook now computes and exports three figures (manuscript Table 3):

| Evaluation design | R² | RMSE | Measures |
|---|---|---|---|
| Apparent (in-sample) | 0.914 | 0.0135 | Reproduction of data already seen |
| Random 10-fold CV | 0.355 | 0.0369 | Interpolation within sampled conditions |
| Blocked 10-fold CV | 0.144 | 0.0425 | Extrapolation to withheld landscape units |

Full-set fitting is retained **only** for variable importance and partial
dependence, where it is appropriate. Predictive accuracy is reported from
cross-validation.

Figure 7 renamed to `Figure_7_Apparent_Fit.png`, titled "Apparent fit — not a
validation plot", with all three R² values annotated.

### Corrected — interpretation of the SOC–EVI relationship

The coefficient itself was right (r = −0.4426, n = 3,507). Its interpretation
was inverted. The manuscript had stated that vegetation vigor declines *below*
11.27 g/kg SOC; the model shows the opposite:

- Mean EVI is identical across the three lowest SOC quintiles (0.231 each),
  falls to 0.225 in the fourth and 0.197 in the fifth, and to 0.173 in the top
  decile.
- The partial dependence curve is flat between ~9 and ~12 g/kg, then declines.
- High-SOC cells are clay-rich, sand-poor (r = +0.309; −0.388), of low bulk
  density (r = −0.650) and higher pH (r = +0.428) — poorly drained Benue
  floodplain soils with suppressed dry-season greenness.
- SOC is nearly uncoupled from urbanisation (NTL–SOC r = −0.076), indicating a
  geomorphic rather than anthropogenic signal.

A comment now flags that Gini importance conveys no directional information.

### Added

- `scripts/spatial_block_cv.py` — cross-validation script; performs genuine
  spatial blocking when `lon`/`lat` are present.
- `results/RF_Model_Performance.csv` — the three evaluation designs.
- `data/DATA_DICTIONARY.md` — column definitions, units, SoilGrids conversions
  and known limitations.

### Changed

- Author header blocks aligned with manuscript authorship; department corrected
  to Human Ecology and Bioelementology.
- Removed the comment `# n_estimators=1000 and full-set fitting to match
  manuscript R2 = 0.914`, which described a fitting choice made to reach a
  number rather than a number arrived at by fitting.

### Known limitation

Grid-cell coordinates are not retained in the analytical table, so blocked
cross-validation uses covariate-space blocks as a proxy for spatial blocks. See
`data/DATA_DICTIONARY.md` for how to enable true spatial blocking.

## [1.0] — Original submission
